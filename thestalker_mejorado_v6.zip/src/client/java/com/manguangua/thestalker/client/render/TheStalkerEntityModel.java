package com.manguangua.thestalker.client.render;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;

/**
 * Modelo bipedo estandar para El Manguangua.
 *
 * En Minecraft 1.21.11 los modelos de entidades reciben un
 * BipedEntityRenderState, no la entidad directamente.
 */
public class TheStalkerEntityModel extends BipedEntityModel<BipedEntityRenderState> {

	public TheStalkerEntityModel(ModelPart root) {
		super(root);
	}

	public static TexturedModelData getTexturedModelData() {
		return TexturedModelData.of(
				BipedEntityModel.getModelData(Dilation.NONE, 0.0F),
				64,
				64
		);
	}

	@Override
	public void setAngles(BipedEntityRenderState state) {
		super.setAngles(state);
	}
}
