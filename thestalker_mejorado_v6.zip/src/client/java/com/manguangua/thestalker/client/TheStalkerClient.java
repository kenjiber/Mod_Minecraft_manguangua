package com.manguangua.thestalker.client;

import com.manguangua.thestalker.TheStalker;
import com.manguangua.thestalker.client.render.TheStalkerEntityModel;
import com.manguangua.thestalker.client.render.TheStalkerEntityRenderer;
import com.manguangua.thestalker.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

/**
 * Entrypoint exclusivo de cliente. Todo lo que solo existe en el cliente
 * (modelo 3D, texturas, renderer) se registra aqui, NUNCA en TheStalker.java.
 */
public class TheStalkerClient implements ClientModInitializer {

	/** Capa del modelo (equivalente al "main" de EntityModelLayers para mobs vanilla). */
	public static final EntityModelLayer THE_STALKER_LAYER =
			new EntityModelLayer(Identifier.of(TheStalker.MOD_ID, "the_stalker"), "main");

	@Override
	public void onInitializeClient() {
		EntityModelLayerRegistry.registerModelLayer(THE_STALKER_LAYER, TheStalkerEntityModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.THE_STALKER, TheStalkerEntityRenderer::new);
		TheStalker.LOGGER.info("[TheStalker] Renderer de cliente registrado.");
	}
}
