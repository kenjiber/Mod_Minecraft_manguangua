package com.manguangua.thestalker.client.render;

import com.manguangua.thestalker.TheStalker;
import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.client.TheStalkerClient;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.util.Identifier;

/**
 * Renderer de El Manguangua compatible con el sistema de RenderState
 * de Minecraft 1.21.11.
 */
public class TheStalkerEntityRenderer
		extends BipedEntityRenderer<TheStalkerEntity, BipedEntityRenderState, TheStalkerEntityModel> {

	private static final Identifier TEXTURE =
			Identifier.of(TheStalker.MOD_ID, "textures/entity/thestalker.png");

	public TheStalkerEntityRenderer(EntityRendererFactory.Context context) {
		super(
				context,
				new TheStalkerEntityModel(
						context.getPart(TheStalkerClient.THE_STALKER_LAYER)
				),
				0.5F
		);
	}

	@Override
	public BipedEntityRenderState createRenderState() {
		return new BipedEntityRenderState();
	}

	@Override
	public Identifier getTexture(BipedEntityRenderState state) {
		return TEXTURE;
	}
}
