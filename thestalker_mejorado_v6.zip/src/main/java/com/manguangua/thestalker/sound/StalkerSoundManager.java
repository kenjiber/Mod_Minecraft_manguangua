package com.manguangua.thestalker.sound;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.registry.ModSounds;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;

/**
 * Control centralizado de los sonidos del Stalker.
 *
 * Importante: solo permite UN sonido del Stalker a la vez. El servidor
 * mantiene un temporizador basado en la duracion real de los .ogg incluidos
 * en el mod, por lo que no se lanzan dos audios superpuestos.
 */
public final class StalkerSoundManager {

	/** 1.60 = 60% mas volumen que el valor base 1.0. */
	private static final float VOLUME_MULTIPLIER = 1.60F;

	private static final int AMBIENT_COOLDOWN_MIN = 180;
	private static final int AMBIENT_COOLDOWN_MAX = 400;

	private static final int DURATION_AMBIENT_1 = 94;
	private static final int DURATION_AMBIENT_2 = 78;
	private static final int DURATION_AMBIENT_3 = 158;
	private static final int DURATION_DESPAIR_1 = 218;
	private static final int DURATION_DESPAIR_2 = 227;
	private static final int DURATION_DESPAIR_3 = 113;
	private static final int DURATION_DOOR_BREAK_1 = 121;
	private static final int DURATION_SPAWN_1 = 154;
	private static final int DURATION_STARE_1 = 41;


	private static final class SoundState {
		private int remainingTicks;
		private boolean playAmbient2After;
		private SoundEvent pendingSound;
		private float pendingVolume = 1.0F;
		private int pendingDurationTicks;
		private boolean pendingAmbient2After;
	}

	private static final java.util.Map<java.util.UUID, SoundState> STATES = new java.util.HashMap<>();

	private StalkerSoundManager() {
	}

	/**
	 * Debe llamarse una vez por tick desde la entidad, en servidor.
	 */
	public static void tick(TheStalkerEntity stalker) {
		if (!(stalker.getEntityWorld() instanceof ServerWorld)) {
			return;
		}

		SoundState state = stateFor(stalker);

		if (state.remainingTicks > 0) {
			state.remainingTicks--;
		}

		if (state.remainingTicks <= 0) {
			if (state.pendingSound != null) {
				SoundEvent pending = state.pendingSound;
				float volume = state.pendingVolume;
				int duration = state.pendingDurationTicks;
				boolean after = state.pendingAmbient2After;

				state.pendingSound = null;
				state.pendingAmbient2After = false;
				playInternal(stalker, pending, volume, duration, after);
			} else if (state.playAmbient2After) {
				state.playAmbient2After = false;
				playInternal(
						stalker,
						ModSounds.STALKER_AMBIENT_AFTER_DOOR,
						1.0F,
						DURATION_AMBIENT_2,
						false
				);
			}
		}
	}

	/** Sonido ambiente normal cuando el Stalker esta cerca. */
	public static void playAmbient(TheStalkerEntity stalker, double distanceToPlayer) {
		if (distanceToPlayer > 32.0D) {
			return;
		}

		int choice = stalker.getRandom().nextInt(3);

		switch (choice) {
			case 0 -> playInternal(
					stalker,
					ModSounds.STALKER_AMBIENT_PRIMARY,
					1.0F,
					DURATION_AMBIENT_1,
					false
			);
			case 1 -> playInternal(
					stalker,
					ModSounds.STALKER_DESPAIR_AMBIENT,
					1.0F,
					DURATION_DESPAIR_2,
					false
			);
			default -> playInternal(
					stalker,
					ModSounds.STALKER_DESPAIR_AMBIENT,
					1.0F,
					DURATION_DESPAIR_3,
					false
			);
		}
	}

	/** Despair 1: solo cuando el jugador golpea al Stalker por primera vez. */
	public static void playDespair1(TheStalkerEntity stalker) {
		playInternal(
				stalker,
				ModSounds.STALKER_DESPAIR_1,
				1.0F,
				DURATION_DESPAIR_1,
				false
		);
	}

	public static void playSpawn(TheStalkerEntity stalker) {
		playInternal(
				stalker,
				ModSounds.STALKER_SPAWN,
				1.0F,
				DURATION_SPAWN_1,
				false
		);
	}

	public static void playStare(TheStalkerEntity stalker) {
		playInternal(
				stalker,
				ModSounds.STALKER_STARE,
				1.0F,
				DURATION_STARE_1,
				false
		);
	}

	/**
	 * Reproduce stalker_door_break_1 y deja preparado stalker_ambient_2
	 * para que empiece inmediatamente despues de que termine.
	 */
	public static void playDoorBreak(TheStalkerEntity stalker) {
		playInternal(
				stalker,
				ModSounds.STALKER_DOOR_BREAK,
				0.8F,
				DURATION_DOOR_BREAK_1,
				true
		);
	}

	private static void playInternal(
				TheStalkerEntity stalker,
				SoundEvent sound,
				float baseVolume,
				int durationTicks,
				boolean playAmbient2After) {

		if (!(stalker.getEntityWorld() instanceof ServerWorld)) {
			return;
		}

		SoundState state = stateFor(stalker);

		// Nunca superponer sonidos del Stalker.
		if (state.remainingTicks > 0) {
			// El primer golpe del jugador es prioritario: se encola para sonar
			// justo despues del audio que ya estaba reproduciendose.
			if (sound == ModSounds.STALKER_DESPAIR_1) {
				state.pendingSound = sound;
				state.pendingVolume = baseVolume;
				state.pendingDurationTicks = durationTicks;
				state.pendingAmbient2After = false;
				state.playAmbient2After = false;
			}
			return;
		}

		float pitch = 1.0F;
		stalker.getEntityWorld().playSound(
				null,
				stalker.getX(),
				stalker.getY(),
				stalker.getZ(),
				sound,
				SoundCategory.HOSTILE,
				baseVolume * VOLUME_MULTIPLIER,
				pitch
		);

		state.remainingTicks = durationTicks;
		state.playAmbient2After = playAmbient2After;
	}

	private static SoundState stateFor(TheStalkerEntity stalker) {
		return STATES.computeIfAbsent(stalker.getUuid(), ignored -> new SoundState());
	}

	/**
	 * Permite reutilizar los mismos valores en el Goal sin duplicar logica.
	 */
	public static int nextAmbientCooldown(TheStalkerEntity stalker) {
		int range = AMBIENT_COOLDOWN_MAX - AMBIENT_COOLDOWN_MIN;
		return AMBIENT_COOLDOWN_MIN + stalker.getRandom().nextInt(range + 1);
	}
}
