package com.manguangua.thestalker;

import com.manguangua.thestalker.command.StalkerCommands;
import com.manguangua.thestalker.registry.ModEntities;
import com.manguangua.thestalker.registry.ModSounds;
import com.manguangua.thestalker.spawn.StalkerSpawnHandler;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Punto de entrada principal (entorno comun: servidor + cliente).
 * <p>
 * Aqui solo se registran cosas que deben existir en ambos lados (entidad,
 * sonidos, comandos, y el "tick" del sistema de spawn). Todo lo que sea
 * exclusivo de renderizado vive en {@code src/client} (ver TheStalkerClient).
 */
public class TheStalker implements ModInitializer {

	/** ID del mod. Se usa para construir todos los Identifier del mod. */
	public static final String MOD_ID = "thestalker";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("[TheStalker] Inicializando El Manguangua...");

		// 1) Registrar el SoundEvent y el EntityType ANTES que nada mas.
		ModSounds.register();
		ModEntities.register();

		// 2) Registrar los comandos /thestalker spawn|despawn|reset
		CommandRegistrationCallback.EVENT.register(StalkerCommands::register);

		// 3) Registrar el "tick" global que controla el spawn automatico
		//    (primer spawn a los 5 minutos, spawns/reapariciones posteriores, etc).
		ServerTickEvents.END_WORLD_TICK.register(StalkerSpawnHandler::onEndWorldTick);

		LOGGER.info("[TheStalker] El Manguangua esta listo. Que tengas suerte.");
	}
}
