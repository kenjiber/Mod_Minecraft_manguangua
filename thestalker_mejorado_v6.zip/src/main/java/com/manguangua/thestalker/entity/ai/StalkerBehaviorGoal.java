package com.manguangua.thestalker.entity.ai;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.sound.StalkerSoundManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

/**
 * Persecucion persistente del jugador objetivo.
 *
 * El Stalker ya no pierde al jugador ni entra en patrulla: mientras el jugador
 * siga conectado y vivo, continua intentando llegar hasta el, incluso si
 * deja de verlo. Tambien puede construir una torre de tablones cuando el
 * jugador esta claramente por encima.
 */
public class StalkerBehaviorGoal extends Goal {

	private static final double APPROACH_CLOSE_DISTANCE = 8.0;
	private static final double CHASE_DISTANCE_THRESHOLD = 18.0;

	private static final double FLEE_DISTANCE_MIN = 20.0;
	private static final double FLEE_DISTANCE_MAX = 30.0;
	private static final int FIRST_HIT_FLEE_TICKS_MIN = 200;
	private static final int FIRST_HIT_FLEE_TICKS_MAX = 300;
	private static final int POST_ATTACK_FLEE_TICKS_MIN = 60;
	private static final int POST_ATTACK_FLEE_TICKS_MAX = 100;

	private static final double STARE_ANGLE_RADIANS = Math.toRadians(20.0);
	private static final double STARE_MAX_DISTANCE = 40.0;
	private static final int STARE_SOUND_COOLDOWN_TICKS = 100;

	private static final double ATTACK_RANGE = 2.3;
	private static final int ATTACK_COOLDOWN_TICKS = 20;

	private static final double SPEED_STALKING = 0.55;
	private static final double SPEED_CHASING = 1.15;
	private static final double SPEED_CHASING_SPRINT = 1.35;
	private static final double SPEED_FLEEING = 1.25;

	/** Cada cuantos ticks como minimo intenta construir hacia arriba. */
	private static final int BUILD_COOLDOWN_TICKS = 10;
	private static final double BUILD_MIN_VERTICAL_ADVANTAGE = 1.5;

	private final TheStalkerEntity stalker;

	private StalkerState state = StalkerState.STALKING;
	private int fleeTicksRemaining = 0;
	private int stareSoundCooldown = 0;
	private int attackCooldown = 0;
	private int buildCooldown = 0;
	private int ambientSoundCooldown;
	private boolean wasBeingWatchedLastTick = false;

	public StalkerBehaviorGoal(TheStalkerEntity stalker) {
		this.stalker = stalker;
		this.ambientSoundCooldown = StalkerSoundManager.nextAmbientCooldown(stalker);
		this.setControls(EnumSet.of(
				Goal.Control.MOVE,
				Goal.Control.LOOK,
				Goal.Control.JUMP
		));
	}

	@Override
	public boolean canStart() {
		return this.stalker.getEntityWorld() instanceof ServerWorld
				&& this.stalker.resolveTargetPlayer() != null;
	}

	@Override
	public boolean shouldContinue() {
		return this.canStart();
	}

	@Override
	public void start() {
		this.state = StalkerState.STALKING;
		this.stalker.setPose(EntityPose.CROUCHING);
	}

	@Override
	public void stop() {
		this.stalker.getNavigation().stop();
	}

	@Override
	public void tick() {
		if (!(this.stalker.getEntityWorld() instanceof ServerWorld world)) {
			return;
		}

		PlayerEntity player = this.stalker.resolveTargetPlayer();
		if (player == null) {
			return;
		}

		double distance = this.stalker.distanceTo(player);
		boolean canSee = this.stalker.canSee(player);

		if (this.attackCooldown > 0) {
			this.attackCooldown--;
		}
		if (this.stareSoundCooldown > 0) {
			this.stareSoundCooldown--;
		}
		if (this.buildCooldown > 0) {
			this.buildCooldown--;
		}

		// Al aparecer, se acerca agachado. Una vez cerca, ya no vuelve a agacharse.
		if (!this.stalker.hasReachedPlayer()) {
			if (distance <= APPROACH_CLOSE_DISTANCE) {
				this.stalker.markReachedPlayer();
			}
		}

		this.stalker.setPose(
				this.stalker.hasReachedPlayer()
						? EntityPose.STANDING
						: EntityPose.CROUCHING
		);

		// Mirar al jugador nunca vuelve a congelar al Stalker.
		boolean beingWatched =
				canSee
						&& distance <= STARE_MAX_DISTANCE
						&& isPlayerLookingAtStalker(player);

		if (beingWatched
					&& !this.wasBeingWatchedLastTick
					&& this.stareSoundCooldown <= 0) {
			StalkerSoundManager.playStare(this.stalker);
			this.stareSoundCooldown = STARE_SOUND_COOLDOWN_TICKS;
		}
		this.wasBeingWatchedLastTick = beingWatched;

		if (this.fleeTicksRemaining > 0) {
			this.state = StalkerState.FLEEING;
		} else if (player.isSprinting() || distance > CHASE_DISTANCE_THRESHOLD) {
			this.state = StalkerState.CHASING;
		} else {
			this.state = StalkerState.STALKING;
		}

		switch (this.state) {
			case STALKING -> tickStalking(player);
			case CHASING -> tickChasing(world, player, distance);
			case FLEEING -> tickFleeing(player);
			case PATROLLING -> tickChasing(world, player, distance);
		}

		// Construccion de apoyo para seguir al jugador si este sube mucho.
		if (this.fleeTicksRemaining <= 0) {
			tryBuildVerticalPath(world, player);
		}

		// Sonidos de ambiente solo cuando esta razonablemente cerca del jugador.
		if (distance <= 32.0D && this.fleeTicksRemaining <= 0) {
			this.ambientSoundCooldown--;
			if (this.ambientSoundCooldown <= 0) {
				StalkerSoundManager.playAmbient(this.stalker, distance);
				this.ambientSoundCooldown = StalkerSoundManager.nextAmbientCooldown(this.stalker);
			}
		}
	}

	/**
	 * Primer golpe recibido por el Stalker: huye y reproduce exclusivamente
	 * stalker_despair_1. Cuando el Stalker golpea al jugador, tambien se aleja,
	 * pero no reproduce despair_1.
	 */
	public void notifyHit(boolean firstHitEver) {
		int min = firstHitEver
				? FIRST_HIT_FLEE_TICKS_MIN
				: POST_ATTACK_FLEE_TICKS_MIN;

		int max = firstHitEver
				? FIRST_HIT_FLEE_TICKS_MAX
				: POST_ATTACK_FLEE_TICKS_MAX;

		this.fleeTicksRemaining =
				min + this.stalker.getRandom().nextInt(max - min + 1);
		this.state = StalkerState.FLEEING;

		if (firstHitEver) {
			StalkerSoundManager.playDespair1(this.stalker);
		}
	}

	private void tickStalking(PlayerEntity player) {
		this.stalker.getLookControl().lookAt(player, 30.0F, 30.0F);
		this.stalker.getNavigation().startMovingTo(player, SPEED_STALKING);
	}

	private void tickChasing(ServerWorld world, PlayerEntity player, double distance) {
		this.stalker.getLookControl().lookAt(player, 30.0F, 30.0F);

		double speed = player.isSprinting()
				? SPEED_CHASING_SPRINT
				: SPEED_CHASING;

		// Se actualiza constantemente aunque el jugador no este visible.
		this.stalker.getNavigation().startMovingTo(player, speed);

		if (this.stalker.hasBeenHit()
				&& distance <= ATTACK_RANGE
				&& this.attackCooldown <= 0) {
			this.attackCooldown = ATTACK_COOLDOWN_TICKS;

			boolean hit = this.stalker.tryAttack(world, player);
			if (hit) {
				this.notifyHit(false);
			}
		}
	}

	private void tickFleeing(PlayerEntity player) {
		this.fleeTicksRemaining--;

		Vec3d away = computeFleePoint(player);
		this.stalker.getNavigation().startMovingTo(
				away.x,
				away.y,
				away.z,
				SPEED_FLEEING
		);
		this.stalker.getLookControl().lookAt(away.x, away.y, away.z);

		if (this.fleeTicksRemaining <= 0) {
			this.state = StalkerState.CHASING;
		}
	}

	/**
	 * Si el jugador esta por encima, coloca tablones de roble bajo el Stalker.
	 * El cambio de bloque empuja al Stalker hacia arriba, formando una torre
	 * vertical que le permite recuperar la altura del jugador.
	 */
	private void tryBuildVerticalPath(ServerWorld world, PlayerEntity player) {
		double verticalDifference = player.getY() - this.stalker.getY();
		if (verticalDifference < BUILD_MIN_VERTICAL_ADVANTAGE) {
			return;
		}
		if (this.buildCooldown > 0) {
			return;
		}
		if (this.stalker.squaredDistanceTo(player) > 24.0D * 24.0D) {
			return;
		}

		BlockPos current = this.stalker.getBlockPos();
		if (current.getY() >= world.getTopYInclusive() - 2) {
			return;
		}

		BlockState currentState = world.getBlockState(current);
		BlockState aboveState = world.getBlockState(current.up());

		// Solo construye si tiene espacio para subir y el bloque actual es aire.
		if (!currentState.isAir() || !aboveState.isAir()) {
			return;
		}

		if (world.setBlockState(current, Blocks.OAK_PLANKS.getDefaultState(), Block.NOTIFY_ALL)) {
			this.buildCooldown = BUILD_COOLDOWN_TICKS;
			this.stalker.getJumpControl().setActive();
			this.stalker.getNavigation().startMovingTo(player, SPEED_CHASING);
		}
	}

	private Vec3d computeFleePoint(PlayerEntity player) {
		Vec3d fromPlayerToStalker =
				this.stalker.getEntityPos().subtract(player.getEntityPos());

		if (fromPlayerToStalker.lengthSquared() < 0.01) {
			double angle = this.stalker.getRandom().nextDouble() * Math.PI * 2.0;
			fromPlayerToStalker = new Vec3d(Math.cos(angle), 0, Math.sin(angle));
		}

		Vec3d direction = fromPlayerToStalker.normalize();
		double distance = FLEE_DISTANCE_MIN
				+ this.stalker.getRandom().nextDouble()
				* (FLEE_DISTANCE_MAX - FLEE_DISTANCE_MIN);

		return player.getEntityPos().add(direction.multiply(distance));
	}

	private boolean isPlayerLookingAtStalker(PlayerEntity player) {
		Vec3d lookDirection = player.getRotationVec(1.0F);
		Vec3d toStalker = this.stalker.getEyePos()
				.subtract(player.getEyePos())
				.normalize();

		double dot = lookDirection.normalize().dotProduct(toStalker);
		double angle = Math.acos(Math.clamp(dot, -1.0, 1.0));
		return angle <= STARE_ANGLE_RADIANS;
	}
}
