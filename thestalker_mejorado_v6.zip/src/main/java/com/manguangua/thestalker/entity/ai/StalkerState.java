package com.manguangua.thestalker.entity.ai;

/**
 * Estados posibles de la maquina de estados de {@code StalkerBehaviorGoal}.
 */
public enum StalkerState {
	/** Acechando: movimiento lento y deliberado, se congela si el jugador lo mira. */
	STALKING,
	/** Persiguiendo activamente: velocidad alta, ignora el "congelado al mirar". */
	CHASING,
	/** Huyendo tras ser golpeado por el jugador (antes o despues de hasBeenHit). */
	FLEEING,
	/** Perdio de vista al jugador: va hacia la ultima posicion conocida y patrulla. */
	PATROLLING
}
