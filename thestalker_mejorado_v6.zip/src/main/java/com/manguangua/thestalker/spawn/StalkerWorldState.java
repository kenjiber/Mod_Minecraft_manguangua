package com.manguangua.thestalker.spawn;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.Uuids;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateType;

import java.util.Optional;
import java.util.UUID;

/**
 * Guarda, a nivel de MUNDO (no de entidad), todo lo necesario para el
 * sistema de spawn: si ya ocurrio el primer spawn (a los 5 minutos),
 * cuando toca el proximo spawn/reaparicion aleatoria, que jugador es el
 * "objetivo" y el UUID de la instancia actual del Stalker (para poder
 * localizarla de nuevo aunque el chunk se descargue).
 *
 * <p><b>Confirmado contra las mappings reales de 1.21.11+build.4:</b> desde
 * 1.21.6, el registro de estados persistentes usa un record de nivel
 * superior {@code PersistentStateType<T>} (ya NO un {@code PersistentState.Type}
 * anidado), y {@code PersistentStateManager#getOrCreate(...)} recibe SOLO
 * ese objeto (el id ya va incluido dentro de el, no como String aparte).
 * {@link PersistentState} en si ya no declara ningun metodo de
 * guardado/lectura: toda la serializacion la hace el {@code Codec} de abajo.
 */
public class StalkerWorldState extends PersistentState {

	/** true en cuanto ha ocurrido el spawn inicial (a los 6000 ticks del primer dia). */
	private boolean firstSpawnDone;
	/** Tiempo de mundo (world.getTime()) en el que toca el siguiente intento de spawn/reaparicion. */
	private long nextSpawnCheckTime;
	/** UUID del jugador "objetivo" (el que creo el mundo / el mas cercano en el primer spawn). */
	private UUID targetPlayerUuid;
	/** UUID de la entidad Stalker actualmente viva en este mundo (null si no existe ninguna). */
	private UUID stalkerEntityUuid;

	public static final Codec<StalkerWorldState> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.BOOL.fieldOf("firstSpawnDone").forGetter(s -> s.firstSpawnDone),
			Codec.LONG.fieldOf("nextSpawnCheckTime").forGetter(s -> s.nextSpawnCheckTime),
			Uuids.CODEC.optionalFieldOf("targetPlayerUuid").forGetter(s -> Optional.ofNullable(s.targetPlayerUuid)),
			Uuids.CODEC.optionalFieldOf("stalkerEntityUuid").forGetter(s -> Optional.ofNullable(s.stalkerEntityUuid))
	).apply(instance, StalkerWorldState::new));

	private StalkerWorldState(boolean firstSpawnDone, long nextSpawnCheckTime,
							   Optional<UUID> targetPlayerUuid, Optional<UUID> stalkerEntityUuid) {
		this.firstSpawnDone = firstSpawnDone;
		this.nextSpawnCheckTime = nextSpawnCheckTime;
		this.targetPlayerUuid = targetPlayerUuid.orElse(null);
		this.stalkerEntityUuid = stalkerEntityUuid.orElse(null);
	}

	public StalkerWorldState() {
		this(false, 6000L, Optional.empty(), Optional.empty());
	}

	/**
	 * id + fabrica (para un estado "vacio" nuevo) + codec (para guardar/cargar).
	 * El cuarto parametro es el DataFixTypes; null es valido y habitual para
	 * datos propios de un mod (no necesitan los "data fixers" de Mojang).
	 */
	public static final PersistentStateType<StalkerWorldState> TYPE = new PersistentStateType<>(
			"thestalker_state",
			StalkerWorldState::new,
			CODEC,
			null
	);

	// ===================== Getters / Setters =====================

	public boolean isFirstSpawnDone() {
		return this.firstSpawnDone;
	}

	public void setFirstSpawnDone(boolean value) {
		this.firstSpawnDone = value;
		this.markDirty();
	}

	public long getNextSpawnCheckTime() {
		return this.nextSpawnCheckTime;
	}

	public void setNextSpawnCheckTime(long ticks) {
		this.nextSpawnCheckTime = ticks;
		this.markDirty();
	}

	public UUID getTargetPlayerUuid() {
		return this.targetPlayerUuid;
	}

	public void setTargetPlayerUuid(UUID uuid) {
		this.targetPlayerUuid = uuid;
		this.markDirty();
	}

	public UUID getStalkerEntityUuid() {
		return this.stalkerEntityUuid;
	}

	public void setStalkerEntityUuid(UUID uuid) {
		this.stalkerEntityUuid = uuid;
		this.markDirty();
	}

	/** Reinicia TODO el estado (usado por /thestalker reset). */
	public void resetAll() {
		this.firstSpawnDone = false;
		this.nextSpawnCheckTime = 6000L;
		this.targetPlayerUuid = null;
		this.stalkerEntityUuid = null;
		this.markDirty();
	}
}
