# TheStalker (El Manguangua)

Mod de Fabric para Minecraft **1.21.11** que anade una entidad hostil que
acecha y persigue a un jugador especifico, con IA de acecho/persecucion,
un sistema de "no puede hacerte dano hasta que tu lo golpees primero",
rotura de puertas, sonidos posicionales aleatorios y spawn automatico
persistente (5 minutos tras crear el mundo, y reapariciones cada 10-30
minutos despues).

---

## 0. Sobre la primera version que te pase

La primera version tenia 10 errores de compilacion (los viste en el
Build Summary de GitHub Actions). Los busque uno por uno contra el
**javadoc real de las mappings 1.21.11+build.4** (https://mappings.dev y
https://maven.fabricmc.net/docs/yarn-1.21.11+build.4/) y ya estan
corregidos:

- `ModEntities.java`: `FabricDefaultAttributeRegistry` habia cambiado de
  paquete hace tiempo (yo use la ruta vieja).
- `StalkerSpawnHandler.java`: `Heightmap` se movio de
  `net.minecraft.util.math` a `net.minecraft.world`.
- `StalkerWorldState.java`: desde la 1.21.6, el registro de un
  `PersistentState` ya NO usa `PersistentState.Type` (anidado); usa un
  record de nivel superior `PersistentStateType<T>`, y
  `getOrCreate(...)` recibe solo ese objeto (el id ya va dentro, no como
  `String` aparte). Reescribi el archivo con el patron real.
- `TheStalkerEntity.java`: desde la 1.21.6, `Entity` ya no lee/escribe
  su NBT con `NbtCompound` directamente: usa `WriteView`/`ReadView`
  (`writeCustomDataToNbt`/`readCustomDataFromNbt` pasaron a llamarse
  `writeCustomData`/`readCustomData`), y los UUID se guardan con
  `view.put(clave, Uuids.CODEC, valor)` en vez de `NbtCompound#putUuid`.
- Un quinto error (`TheStalkerEntity.java` linea 104, "cannot find
  symbol" en un `instanceof ServerWorld`) no tenia una causa propia que
  yo pueda ver: `ServerWorld` se usa sin problemas en otros archivos del
  mismo build. Todo apunta a que era un efecto en cascada del error real
  de `writeCustomDataToNbt` (un error grave en una clase puede hacer que
  el compilador reporte fallos fantasma en otras lineas de la misma
  clase). Deberia desaparecer solo al recompilar; si sigue apareciendo,
  pasame el log completo de esa linea.

Si te vuelve a fallar el build, pega aqui el resumen de errores (como
la captura que me pasaste) y lo reviso igual de rapido.

---

## 1. Estructura del proyecto

```
thestalker/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── src/main/java/com/manguangua/thestalker/
│   ├── TheStalker.java                 (entrypoint main)
│   ├── registry/ModEntities.java       (registro del EntityType)
│   ├── registry/ModSounds.java         (registro de SoundEvents)
│   ├── entity/TheStalkerEntity.java    (la entidad)
│   ├── entity/ai/StalkerState.java
│   ├── entity/ai/StalkerBehaviorGoal.java     (acecho/persecucion/huida/patrulla)
│   ├── entity/ai/StalkerDoorBreakingGoal.java (romper puertas/vallas)
│   ├── sound/StalkerSoundManager.java
│   ├── spawn/StalkerWorldState.java    (estado persistente del mundo)
│   ├── spawn/StalkerSpawnHandler.java  (logica de CUANDO spawnear)
│   └── command/StalkerCommands.java    (/thestalker spawn|despawn|reset)
├── src/client/java/com/manguangua/thestalker/client/
│   ├── TheStalkerClient.java           (entrypoint client)
│   └── render/TheStalkerEntityModel.java, TheStalkerEntityRenderer.java
└── src/main/resources/
    ├── fabric.mod.json
    └── assets/thestalker/
        ├── sounds.json
        ├── lang/es_es.json, en_us.json
        ├── textures/entity/thestalker.png   (PLACEHOLDER, ver seccion 3)
        └── sounds/*.ogg                     (tus audios YA incluidos, ver seccion 4)
```

No hay ningun Mixin: todo el comportamiento (incluida la rotura de
puertas) se implementa con `Goal`s normales de Fabric/vanilla, asi que no
hay `mixins.json` que mantener.

---

## 2. Como compilar

1. Instala **JDK 21**.
2. Necesitas conexion a internet la primera vez (Gradle descarga
   Minecraft, las mappings y Fabric API).
3. Como no puedo generar el `.jar` del Gradle Wrapper aqui (sin
   internet), tienes dos opciones:
   - **Opcion A (recomendada):** abre el proyecto directamente en
     **IntelliJ IDEA** con el plugin de Gradle; IntelliJ genera el
     wrapper solo al importar. O bien
   - **Opcion B:** si tienes Gradle instalado en tu maquina, ejecuta una
     vez `gradle wrapper --gradle-version 8.11.1` dentro de la carpeta
     del proyecto para generar `gradlew`, `gradlew.bat` y el `.jar` del
     wrapper (ya te he dejado `gradle-wrapper.properties` con la version
     correcta).
4. Compilar: `./gradlew build` (o desde IntelliJ: Gradle > Tasks > build).
5. El `.jar` resultante queda en `build/libs/thestalker-1.0.0.jar`.
6. Para probarlo rapido: `./gradlew runClient` te abre un cliente de
   Minecraft con el mod ya cargado (crea un mundo nuevo y espera 5
   minutos, o usa `/thestalker spawn` con trampas activadas).

Si un `build.gradle`/`gradle.properties` da error de version no
encontrada, entra en **https://fabricmc.net/develop**, selecciona
Minecraft 1.21.11 y copia los numeros exactos que te de esa pagina (a
veces publican una revision nueva de un dia para otro).

---

## 3. Anadir tu skin/textura

La imagen que me pasaste es un **mockup/diagrama de referencia** (muestra
las partes por separado con etiquetas: Head, Outer Hat Layer, Torso,
brazos, piernas...), no el archivo de textura final tal cual lo necesita
Minecraft. Minecraft necesita un PNG **plano de 64x64 px** con el layout
clasico de skins (el mismo formato que usan Steve/Zombie/Husk).

El modelo ya esta preparado para ese formato exacto (usa
`BipedEntityModel.getModelData(...)`, que es el mismo mapeo UV que un
skin de jugador clasico con brazos anchos), incluyendo la capa exterior
de la gorra. Pasos:

1. Crea (o exporta desde tu diseno) un PNG de 64x64 con el layout
   clasico de skin (puedes usar cualquier editor de skins de Minecraft,
   como Blockbench, para partir de tu boceto).
2. Sustituye `src/main/resources/assets/thestalker/textures/entity/thestalker.png`
   (ahora mismo es un placeholder magenta/negro tipo "textura ausente",
   a proposito, para que sea obvio que hay que cambiarlo).
3. No hace falta tocar ningun archivo Java: el renderer ya apunta a esa
   ruta fija.

---

## 4. Los audios: ya estan incluidos y mapeados

Los 9 `.ogg` que subiste ya estan copiados dentro de
`assets/thestalker/sounds/` (comprobe con `ffprobe` que los 9 son Ogg
**Vorbis** valido, formato que Minecraft soporta de forma nativa — no
hizo falta convertir nada).

Como no puedo "escuchar" el contenido de cada audio, los distribui por
duracion/nombre de forma razonable. **Revisalo y reordena si algun clip
no encaja en su categoria** (es tan facil como renombrar los archivos o
editar `sounds.json`):

| Tu archivo original | Renombrado a | Evento / cuando suena |
|---|---|---|
| `abranlapuerta.ogg` | `stalker_door_break_1.ogg` | **Solo** al golpear una puerta/valla (evento `stalker.door_break`, llamado unicamente desde `StalkerDoorBreakingGoal`) |
| `VID_..._120232.ogg` (2.0s) | `stalker_stare_1.ogg` | Cuando el jugador lo mira fijamente |
| `VID_..._120147.ogg` (7.7s) | `stalker_spawn_1.ogg` | Al aparecer por primera vez |
| `quemanguangua.ogg` | `stalker_ambient_1.ogg` | **El sonido "estrella"**: evento propio `stalker.ambient_primary`, con **70% de probabilidad** cada vez que toca sonido ambiente (mientras acecha/persigue). Es, con diferencia, el audio que mas se reproduce de toda la entidad. Ajustable en `StalkerSoundManager.AMBIENT_PRIMARY_CHANCE` |
| `216818..._115523.ogg` | `stalker_ambient_2.ogg` | El otro 30% de las veces, sonido ambiente (variedad) |
| `216818..._115957.ogg` | `stalker_ambient_3.ogg` | El otro 30% de las veces, sonido ambiente (variedad) |
| `216818..._115709.ogg` | `stalker_despair_1.ogg` | Al ser golpeado / huyendo |
| `216818..._115820.ogg` | `stalker_despair_2.ogg` | Al ser golpeado / huyendo |
| `bc39c922..._115059.ogg` | `stalker_despair_3.ogg` | Al ser golpeado / huyendo |

Para anadir MAS variantes en el futuro (sin tocar Java): copia el
`.ogg` nuevo a esa misma carpeta y anade su ruta a la lista `"sounds"`
del evento correspondiente en `sounds.json`.

---

## 5. Resumen de como funciona el comportamiento

- **Objetivo:** al primer spawn se guarda el UUID de "el jugador que
  creo el mundo" (heuristica: si hay un solo jugador, ese; si hay
  varios, el mas cercano al spawn del mundo en ese momento). Si ese
  jugador se desconecta, cae al jugador vivo mas cercano como respaldo
  (tal y como pediste).
- **Acecho vs persecucion:** un unico `Goal` (`StalkerBehaviorGoal`)
  decide el estado segun si te ve, si corres, y a que distancia estas.
  Se congela unos instantes si lo miras fijamente (calculado con el
  angulo entre tu vector de mirada y el vector hacia el).
- **No puede hacerte dano hasta que lo golpees:** `hasBeenHit` (NBT
  persistente). Antes de eso, `tryAttack` esta bloqueado a nivel de
  codigo, no solo de IA.
- **Tras el primer golpe:** huye 10-15s reproduciendo el sonido de
  "desesperacion", y despues persigue mas agresivamente y SI hace dano;
  tras cada golpe que el te da, vuelve a huir brevemente (gato y raton).
- **Puertas/vallas:** `StalkerDoorBreakingGoal` (prioridad mas alta que
  el goal principal) detecta puertas/trampillas/vallas cerradas a menos
  de 8 bloques, se acerca, golpea una vez por segundo (sonido incluido)
  y la rompe tras 7 golpes (puertas/trampillas) o 14 (vallas).
- **Persistencia:** la entidad tiene `setPersistent()` activo y
  `canImmediatelyDespawn` devuelve siempre `false`, asi que nunca
  desaparece por estar lejos. Si la matas, el sistema de spawn puede
  crear una nueva en la siguiente ventana de 10-30 minutos.

## 6. Comandos

- `/thestalker spawn` — invoca uno cerca de quien ejecuta el comando.
- `/thestalker despawn` — elimina cualquier instancia actualmente cargada.
- `/thestalker reset` — elimina instancias y borra TODO el estado
  guardado (como si el mundo fuese nuevo: volvera a spawnear a los 5
  minutos... del "ahora", ya que el reloj de mundo no se puede reiniciar).

Todos requieren nivel de permiso de operador (2).

---

## 7. Constantes faciles de ajustar

Casi todos los numeros de diseno (distancias, tiempos, velocidades,
numero de golpes para romper una puerta) estan como constantes al
principio de `StalkerBehaviorGoal.java`, `StalkerDoorBreakingGoal.java`
y `StalkerSpawnHandler.java`, comentadas en espanol.

## 8. CI (GitHub Actions)

`.github/workflows/build.yml` compila el mod en cada push/PR con Gradle 9.2.1
(la misma version que ya usaba tu build) y sube el `.jar` resultante como
artefacto descargable. Si el build falla, tambien sube los reportes de
Gradle completos (`build/reports`) como artefacto, asi que ya no hace
falta capturar de pantalla el resumen: puedes descargar el log entero
desde la pestana Actions -> el run que fallo -> Artifacts.

El workflow busca solo donde esta `settings.gradle` (raiz del repo o una
subcarpeta como `thestalker/`), asi que funciona sin importar si subiste
el contenido del zip a la raiz del repo o dentro de una carpeta. Si el
build falla con "No se encontro ningun settings.gradle", el propio log
imprime el contenido del repo para que veas donde quedaron los archivos.
