# TheStalker (El Manguangua)

Mod de Fabric para Minecraft **1.21.11** que anade una entidad hostil que
acecha y persigue a un jugador especifico, con IA de acecho/persecucion,
un sistema de "no puede hacerte dano hasta que tu lo golpees primero",
rotura de puertas, sonidos posicionales aleatorios y spawn automatico
persistente (5 minutos tras crear el mundo, y reapariciones cada 10-30
minutos despues).

---

## 0. Antes de nada: por que esto puede necesitar ajustes

Minecraft 1.21.11 es una version muy reciente. He verificado por internet
las versiones concretas de Fabric Loader / Fabric API / Yarn mappings
para que `gradle.properties` sea correcto **a fecha de hoy**, pero:

- **No he podido compilar este proyecto** (mi entorno de trabajo no tiene
  acceso a internet para descargar Minecraft/Fabric/Gradle), asi que no
  puedo garantizarte que compile a la primera.
- Varias partes de la API de Minecraft cambian de una version a otra
  (nombres de metodos, firmas). He usado los patrones mas recientes que
  conozco con confianza razonable, y he dejado comentarios `NOTA DE
  VERSION` en el codigo, en los 3 sitios con mas probabilidad de necesitar
  un ajuste:
  1. `TheStalkerEntity#damage(...)` y `#tryAttack(...)` (firma con `ServerWorld`).
  2. `StalkerWorldState.java` (el sistema `PersistentState` basado en `Codec`).
  3. `ModEntities.java` (`EntityType.Builder#build(RegistryKey)`).

Si algo no compila, el propio IDE (IntelliJ/Eclipse) te dira la firma
correcta con "no sobreescribe ningun metodo" + autocompletado; son ajustes
pequenos y localizados, no un rediseno.

---

## 1. Estructura del proyecto

```
thestalker/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── src/main/java/com/manguangua/thestalker/
│   ├── TheStalker.java                 (entrypoint main)
│   ├── registry/ModEntities.java       (registro del EntityType)
│   ├── registry/ModSounds.java         (registro de SoundEvents)
│   ├── entity/TheStalkerEntity.java    (la entidad)
│   ├── entity/ai/StalkerState.java
│   ├── entity/ai/StalkerBehaviorGoal.java     (acecho/persecucion/huida/patrulla)
│   ├── entity/ai/StalkerDoorBreakingGoal.java (romper puertas/vallas)
│   ├── sound/StalkerSoundManager.java
│   ├── spawn/StalkerWorldState.java    (estado persistente del mundo)
│   ├── spawn/StalkerSpawnHandler.java  (logica de CUANDO spawnear)
│   └── command/StalkerCommands.java    (/thestalker spawn|despawn|reset)
├── src/client/java/com/manguangua/thestalker/client/
│   ├── TheStalkerClient.java           (entrypoint client)
│   └── render/TheStalkerEntityModel.java, TheStalkerEntityRenderer.java
└── src/main/resources/
    ├── fabric.mod.json
    └── assets/thestalker/
        ├── sounds.json
        ├── lang/es_es.json, en_us.json
        ├── textures/entity/thestalker.png   (PLACEHOLDER, ver seccion 3)
        └── sounds/*.ogg                     (tus audios YA incluidos, ver seccion 4)
```

No hay ningun Mixin: todo el comportamiento (incluida la rotura de
puertas) se implementa con `Goal`s normales de Fabric/vanilla, asi que no
hay `mixins.json` que mantener.

---

## 2. Como compilar

1. Instala **JDK 21**.
2. Necesitas conexion a internet la primera vez (Gradle descarga
   Minecraft, las mappings y Fabric API).
3. Como no puedo generar el `.jar` del Gradle Wrapper aqui (sin
   internet), tienes dos opciones:
   - **Opcion A (recomendada):** abre el proyecto directamente en
     **IntelliJ IDEA** con el plugin de Gradle; IntelliJ genera el
     wrapper solo al importar. O bien
   - **Opcion B:** si tienes Gradle instalado en tu maquina, ejecuta una
     vez `gradle wrapper --gradle-version 8.11.1` dentro de la carpeta
     del proyecto para generar `gradlew`, `gradlew.bat` y el `.jar` del
     wrapper (ya te he dejado `gradle-wrapper.properties` con la version
     correcta).
4. Compilar: `./gradlew build` (o desde IntelliJ: Gradle > Tasks > build).
5. El `.jar` resultante queda en `build/libs/thestalker-1.0.0.jar`.
6. Para probarlo rapido: `./gradlew runClient` te abre un cliente de
   Minecraft con el mod ya cargado (crea un mundo nuevo y espera 5
   minutos, o usa `/thestalker spawn` con trampas activadas).

Si un `build.gradle`/`gradle.properties` da error de version no
encontrada, entra en **https://fabricmc.net/develop**, selecciona
Minecraft 1.21.11 y copia los numeros exactos que te de esa pagina (a
veces publican una revision nueva de un dia para otro).

---

## 3. Anadir tu skin/textura

La imagen que me pasaste es un **mockup/diagrama de referencia** (muestra
las partes por separado con etiquetas: Head, Outer Hat Layer, Torso,
brazos, piernas...), no el archivo de textura final tal cual lo necesita
Minecraft. Minecraft necesita un PNG **plano de 64x64 px** con el layout
clasico de skins (el mismo formato que usan Steve/Zombie/Husk).

El modelo ya esta preparado para ese formato exacto (usa
`BipedEntityModel.getModelData(...)`, que es el mismo mapeo UV que un
skin de jugador clasico con brazos anchos), incluyendo la capa exterior
de la gorra. Pasos:

1. Crea (o exporta desde tu diseno) un PNG de 64x64 con el layout
   clasico de skin (puedes usar cualquier editor de skins de Minecraft,
   como Blockbench, para partir de tu boceto).
2. Sustituye `src/main/resources/assets/thestalker/textures/entity/thestalker.png`
   (ahora mismo es un placeholder magenta/negro tipo "textura ausente",
   a proposito, para que sea obvio que hay que cambiarlo).
3. No hace falta tocar ningun archivo Java: el renderer ya apunta a esa
   ruta fija.

---

## 4. Los audios: ya estan incluidos y mapeados

Los 9 `.ogg` que subiste ya estan copiados dentro de
`assets/thestalker/sounds/` (comprobe con `ffprobe` que los 9 son Ogg
**Vorbis** valido, formato que Minecraft soporta de forma nativa — no
hizo falta convertir nada).

Como no puedo "escuchar" el contenido de cada audio, los distribui por
duracion/nombre de forma razonable. **Revisalo y reordena si algun clip
no encaja en su categoria** (es tan facil como renombrar los archivos o
editar `sounds.json`):

| Tu archivo original | Renombrado a | Evento / cuando suena |
|---|---|---|
| `abranlapuerta.ogg` | `stalker_door_break_1.ogg` | **Solo** al golpear una puerta/valla (evento `stalker.door_break`, llamado unicamente desde `StalkerDoorBreakingGoal`) |
| `VID_..._120232.ogg` (2.0s) | `stalker_stare_1.ogg` | Cuando el jugador lo mira fijamente |
| `VID_..._120147.ogg` (7.7s) | `stalker_spawn_1.ogg` | Al aparecer por primera vez |
| `quemanguangua.ogg` | `stalker_ambient_1.ogg` | **El sonido "estrella"**: evento propio `stalker.ambient_primary`, con **70% de probabilidad** cada vez que toca sonido ambiente (mientras acecha/persigue). Es, con diferencia, el audio que mas se reproduce de toda la entidad. Ajustable en `StalkerSoundManager.AMBIENT_PRIMARY_CHANCE` |
| `216818..._115523.ogg` | `stalker_ambient_2.ogg` | El otro 30% de las veces, sonido ambiente (variedad) |
| `216818..._115957.ogg` | `stalker_ambient_3.ogg` | El otro 30% de las veces, sonido ambiente (variedad) |
| `216818..._115709.ogg` | `stalker_despair_1.ogg` | Al ser golpeado / huyendo |
| `216818..._115820.ogg` | `stalker_despair_2.ogg` | Al ser golpeado / huyendo |
| `bc39c922..._115059.ogg` | `stalker_despair_3.ogg` | Al ser golpeado / huyendo |

Para anadir MAS variantes en el futuro (sin tocar Java): copia el
`.ogg` nuevo a esa misma carpeta y anade su ruta a la lista `"sounds"`
del evento correspondiente en `sounds.json`.

---

## 5. Resumen de como funciona el comportamiento

- **Objetivo:** al primer spawn se guarda el UUID de "el jugador que
  creo el mundo" (heuristica: si hay un solo jugador, ese; si hay
  varios, el mas cercano al spawn del mundo en ese momento). Si ese
  jugador se desconecta, cae al jugador vivo mas cercano como respaldo
  (tal y como pediste).
- **Acecho vs persecucion:** un unico `Goal` (`StalkerBehaviorGoal`)
  decide el estado segun si te ve, si corres, y a que distancia estas.
  Se congela unos instantes si lo miras fijamente (calculado con el
  angulo entre tu vector de mirada y el vector hacia el).
- **No puede hacerte dano hasta que lo golpees:** `hasBeenHit` (NBT
  persistente). Antes de eso, `tryAttack` esta bloqueado a nivel de
  codigo, no solo de IA.
- **Tras el primer golpe:** huye 10-15s reproduciendo el sonido de
  "desesperacion", y despues persigue mas agresivamente y SI hace dano;
  tras cada golpe que el te da, vuelve a huir brevemente (gato y raton).
- **Puertas/vallas:** `StalkerDoorBreakingGoal` (prioridad mas alta que
  el goal principal) detecta puertas/trampillas/vallas cerradas a menos
  de 8 bloques, se acerca, golpea una vez por segundo (sonido incluido)
  y la rompe tras 7 golpes (puertas/trampillas) o 14 (vallas).
- **Persistencia:** la entidad tiene `setPersistent()` activo y
  `canImmediatelyDespawn` devuelve siempre `false`, asi que nunca
  desaparece por estar lejos. Si la matas, el sistema de spawn puede
  crear una nueva en la siguiente ventana de 10-30 minutos.

## 6. Comandos

- `/thestalker spawn` — invoca uno cerca de quien ejecuta el comando.
- `/thestalker despawn` — elimina cualquier instancia actualmente cargada.
- `/thestalker reset` — elimina instancias y borra TODO el estado
  guardado (como si el mundo fuese nuevo: volvera a spawnear a los 5
  minutos... del "ahora", ya que el reloj de mundo no se puede reiniciar).

Todos requieren nivel de permiso de operador (2).

---

## 7. Constantes faciles de ajustar

Casi todos los numeros de diseno (distancias, tiempos, velocidades,
numero de golpes para romper una puerta) estan como constantes al
principio de `StalkerBehaviorGoal.java`, `StalkerDoorBreakingGoal.java`
y `StalkerSpawnHandler.java`, comentadas en espanol.
