package com.manguangua.thestalker.spawn;

import com.manguangua.thestalker.TheStalker;
import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.sound.StalkerSoundManager;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

public final class StalkerSpawnHandler {

    private static final double FIRST_SPAWN_MIN_DIST = 30.0;
    private static final double FIRST_SPAWN_MAX_DIST = 50.0;
    private static final double RESPAWN_MIN_DIST = 40.0;
    private static final double RESPAWN_MAX_DIST = 80.0;

    private static final long RESPAWN_INTERVAL_MIN_TICKS = 12_000L;
    private static final long RESPAWN_INTERVAL_MAX_TICKS = 36_000L;

    private static final int MAX_PLACEMENT_ATTEMPTS = 30;

    private StalkerSpawnHandler() {
    }

    public static void onEndWorldTick(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) {
            return;
        }

        StalkerWorldState state = getState(world);
        long worldTime = world.getTime();

        if (!state.isFirstSpawnDone()) {
            if (worldTime >= 6000L) {
                attemptFirstSpawn(world, state);
            }
            return;
        }

        if (worldTime >= state.getNextSpawnCheckTime()) {
            attemptRespawnCheck(world, state);
            scheduleNextCheck(world, state);
        }
    }

    private static void attemptFirstSpawn(ServerWorld world, StalkerWorldState state) {
        PlayerEntity target = pickWorldCreator(world);
        if (target == null) {
            return;
        }

        BlockPos spawnPos = findValidSpawnPos(world, target, FIRST_SPAWN_MIN_DIST, FIRST_SPAWN_MAX_DIST, true);
        if (spawnPos == null) {
            return;
        }

        TheStalkerEntity stalker = spawnAt(world, spawnPos, target);
        if (stalker == null) {
            return;
        }

        state.setTargetPlayerUuid(target.getUuid());
        state.setStalkerEntityUuid(stalker.getUuid());
        state.setFirstSpawnDone(true);
        scheduleNextCheck(world, state);

        StalkerSoundManager.playSpawn(stalker);
        TheStalker.LOGGER.info("[TheStalker] Primer spawn realizado cerca de {}", target.getName().getString());
    }

    private static void attemptRespawnCheck(ServerWorld world, StalkerWorldState state) {
        UUID existingUuid = state.getStalkerEntityUuid();
        if (existingUuid != null) {
            return;
        }

        PlayerEntity target = resolveTargetOrNearest(world, state);
        if (target == null) {
            return;
        }

        BlockPos spawnPos = findValidSpawnPos(world, target, RESPAWN_MIN_DIST, RESPAWN_MAX_DIST, false);
        if (spawnPos == null) {
            return;
        }

        TheStalkerEntity stalker = spawnAt(world, spawnPos, target);
        if (stalker == null) {
            return;
        }
        state.setStalkerEntityUuid(stalker.getUuid());
        StalkerSoundManager.playSpawn(stalker);
        TheStalker.LOGGER.info("[TheStalker] El Manguangua ha reaparecido.");
    }

    private static void scheduleNextCheck(ServerWorld world, StalkerWorldState state) {
        long range = RESPAWN_INTERVAL_MAX_TICKS - RESPAWN_INTERVAL_MIN_TICKS + 1;
        long delay = RESPAWN_INTERVAL_MIN_TICKS + Math.floorMod(world.getRandom().nextLong(), range);
        state.setNextSpawnCheckTime(world.getTime() + delay);
    }

    public static void onStalkerDied(ServerWorld world, UUID deadStalkerUuid) {
        StalkerWorldState state = getState(world);
        if (deadStalkerUuid.equals(state.getStalkerEntityUuid())) {
            state.setStalkerEntityUuid(null);
        }
    }

    public static StalkerWorldState getState(ServerWorld world) {
        // getOrCreate sigue existiendo, pero la firma de TYPE cambió (ver StalkerWorldState).
        return world.getPersistentStateManager().getOrCreate(StalkerWorldState.TYPE, "thestalker_state");
    }

    private static PlayerEntity pickWorldCreator(ServerWorld world) {
        List<? extends PlayerEntity> players = world.getPlayers();
        if (players.isEmpty()) {
            return null;
        }
        if (players.size() == 1) {
            return players.get(0);
        }
        BlockPos worldSpawn = world.getSpawnPos();
        PlayerEntity closest = null;
        double bestDist = Double.MAX_VALUE;
        for (PlayerEntity p : players) {
            double d = p.getBlockPos().getSquaredDistance(worldSpawn);
            if (d < bestDist) {
                bestDist = d;
                closest = p;
            }
        }
        return closest;
    }

    private static PlayerEntity resolveTargetOrNearest(ServerWorld world, StalkerWorldState state) {
        UUID targetUuid = state.getTargetPlayerUuid();
        if (targetUuid != null) {
            PlayerEntity p = world.getPlayerByUuid(targetUuid);
            if (p != null && p.isAlive()) {
                return p;
            }
        }
        return pickWorldCreator(world);
    }

    public static TheStalkerEntity spawnAt(ServerWorld world, BlockPos pos, PlayerEntity target) {
        TheStalkerEntity stalker = TheStalkerEntity.create(world);
        if (stalker == null) {
            return null;
        }
        stalker.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0.0F, 0.0F);
        stalker.setTargetPlayer(target.getUuid());
        if (!world.spawnEntity(stalker)) {
            return null;
        }
        return stalker;
    }

    public static BlockPos findValidSpawnPos(ServerWorld world, PlayerEntity player,
                                               double minDist, double maxDist, boolean preferOutOfSight) {
        Vec3d playerLook = preferOutOfSight ? player.getRotationVec(1.0F) : null;

        for (int attempt = 0; attempt < MAX_PLACEMENT_ATTEMPTS; attempt++) {
            double angle = world.getRandom().nextDouble() * Math.PI * 2.0;
            double dist = minDist + world.getRandom().nextDouble() * (maxDist - minDist);
            double dx = Math.cos(angle) * dist;
            double dz = Math.sin(angle) * dist;

            if (preferOutOfSight && playerLook != null) {
                double dot = (playerLook.x * dx + playerLook.z * dz);
                if (dot > 0 && attempt < MAX_PLACEMENT_ATTEMPTS / 2) {
                    continue;
                }
            }

            int x = player.getBlockPos().getX() + (int) Math.round(dx);
            int z = player.getBlockPos().getZ() + (int) Math.round(dz);
            int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);

            BlockPos candidate = new BlockPos(x, y, z);
            if (isValidGround(world, candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private static boolean isValidGround(ServerWorld world, BlockPos pos) {
        BlockPos below = pos.down();
        BlockState belowState = world.getBlockState(below);
        if (belowState.isAir() || !belowState.getFluidState().isEmpty()) {
            return false;
        }
        if (!belowState.isSolidBlock(world, below)) {
            return false;
        }
        return world.getBlockState(pos).isAir() && world.getBlockState(pos.up()).isAir();
    }
}