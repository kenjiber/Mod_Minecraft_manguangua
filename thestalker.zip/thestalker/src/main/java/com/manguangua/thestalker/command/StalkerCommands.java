package com.manguangua.thestalker.command;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.spawn.StalkerSpawnHandler;
import com.manguangua.thestalker.spawn.StalkerWorldState;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/**
 * Comandos de administrador para pruebas:
 *   /thestalker spawn    -> invoca uno cerca de quien ejecuta el comando (o del primer jugador conectado)
 *   /thestalker despawn  -> elimina cualquier instancia cargada actualmente
 *   /thestalker reset    -> elimina instancias + reinicia todo el estado guardado (como si el mundo fuese nuevo)
 * <p>
 * Requieren nivel de permiso 2 (operador), como cualquier comando de administracion.
 */
public final class StalkerCommands {

	private StalkerCommands() {
	}

	public static void register(CommandDispatcher<ServerCommandSource> dispatcher,
								 CommandRegistryAccess registryAccess,
								 CommandManager.RegistrationEnvironment environment) {
		dispatcher.register(CommandManager.literal("thestalker")
				.requires(source -> source.hasPermissionLevel(2))
				.then(CommandManager.literal("spawn").executes(ctx -> spawn(ctx.getSource())))
				.then(CommandManager.literal("despawn").executes(ctx -> despawn(ctx.getSource())))
				.then(CommandManager.literal("reset").executes(ctx -> reset(ctx.getSource())))
		);
	}

	private static int spawn(ServerCommandSource source) {
		ServerWorld world = source.getWorld();
		PlayerEntity target = resolveCommandTarget(source, world);
		if (target == null) {
			source.sendError(Text.translatable("commands.thestalker.not_found"));
			return 0;
		}

		BlockPos pos = StalkerSpawnHandler.findValidSpawnPos(world, target, 10.0, 20.0, false);
		if (pos == null) {
			source.sendError(Text.literal("No se encontro un punto valido cerca para invocarlo."));
			return 0;
		}

		TheStalkerEntity stalker = StalkerSpawnHandler.spawnAt(world, pos, target);
		if (stalker == null) {
			source.sendError(Text.literal("No se pudo invocar al Stalker (spawnEntity fallo)."));
			return 0;
		}

		StalkerWorldState state = StalkerSpawnHandler.getState(world);
		state.setStalkerEntityUuid(stalker.getUuid());
		state.setTargetPlayerUuid(target.getUuid());
		state.setFirstSpawnDone(true);

		Text targetName = target.getName();
		source.sendFeedback(() -> Text.translatable("commands.thestalker.spawned", targetName), true);
		return 1;
	}

	private static int despawn(ServerCommandSource source) {
		ServerWorld world = source.getWorld();
		List<TheStalkerEntity> found = findLoadedStalkers(world);
		if (found.isEmpty()) {
			source.sendError(Text.translatable("commands.thestalker.not_found"));
			return 0;
		}
		for (TheStalkerEntity e : found) {
			e.discard();
		}
		StalkerSpawnHandler.getState(world).setStalkerEntityUuid(null);
		source.sendFeedback(() -> Text.translatable("commands.thestalker.despawned"), true);
		return 1;
	}

	private static int reset(ServerCommandSource source) {
		ServerWorld world = source.getWorld();
		for (TheStalkerEntity e : findLoadedStalkers(world)) {
			e.discard();
		}
		StalkerSpawnHandler.getState(world).resetAll();
		source.sendFeedback(() -> Text.translatable("commands.thestalker.reset"), true);
		return 1;
	}

	private static List<TheStalkerEntity> findLoadedStalkers(ServerWorld world) {
		List<TheStalkerEntity> found = new ArrayList<>();
		for (Entity e : world.iterateEntities()) {
			if (e instanceof TheStalkerEntity stalker) {
				found.add(stalker);
			}
		}
		return found;
	}

	private static PlayerEntity resolveCommandTarget(ServerCommandSource source, ServerWorld world) {
		if (source.getEntity() instanceof ServerPlayerEntity player) {
			return player;
		}
		List<ServerPlayerEntity> players = world.getPlayers();
		return players.isEmpty() ? null : players.get(0);
	}
}
