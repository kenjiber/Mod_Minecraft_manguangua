package com.manguangua.thestalker.registry;

import com.manguangua.thestalker.TheStalker;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/**
 * Todos los SoundEvent personalizados de la entidad.
 * Cada uno de estos IDs debe tener una entrada equivalente en
 * assets/thestalker/sounds.json (ya preparada), que a su vez apunta
 * a los .ogg dentro de assets/thestalker/sounds/.
 * <p>
 * NO hace falta tocar esta clase para anadir/cambiar audios: solo
 * sustituye los .ogg y, si quieres mas variantes, anade entradas en
 * sounds.json dentro de la lista "sounds" del evento correspondiente.
 */
public final class ModSounds {

	public static final SoundEvent STALKER_AMBIENT = register("stalker.ambient");
	public static final SoundEvent STALKER_AMBIENT_PRIMARY = register("stalker.ambient_primary");
	public static final SoundEvent STALKER_DESPAIR = register("stalker.despair");
	public static final SoundEvent STALKER_SPAWN = register("stalker.spawn");
	public static final SoundEvent STALKER_STARE = register("stalker.stare");
	public static final SoundEvent STALKER_DOOR_BREAK = register("stalker.door_break");

	private ModSounds() {
	}

	private static SoundEvent register(String path) {
		Identifier id = Identifier.of(TheStalker.MOD_ID, path);
		return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
	}

	/** Llamado una vez desde TheStalker#onInitialize(). */
	public static void register() {
		// La carga estatica de esta clase ya ejecuta los Registry.register(...) de arriba.
		TheStalker.LOGGER.info("[TheStalker] Sonidos registrados.");
	}
}
