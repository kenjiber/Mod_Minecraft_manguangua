package com.manguangua.thestalker.client.render;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.Dilation;

/**
 * Modelo "biped" estandar: cabeza + capa exterior de gorra/sombrero, torso,
 * brazos y piernas, con el mismo mapeo UV 64x64 que usan Zombie/Husk/Player
 * (coincide con la referencia de skin que nos diste: Head / Outer Hat Layer /
 * Torso / Left-Right Arm / Left-Right Leg / Front-Back).
 * <p>
 * {@code BipedEntityModel.getModelData(...)} ya incluye el cubo de la "gorra"
 * (dilatado, superpuesto a la cabeza) que se pinta desde la misma textura
 * .png: solo tienes que dibujar el diseno de la gorra en esa zona del PNG
 * (la region "Outer Hat Layer" de tu imagen de referencia) y aparecera sola,
 * sin tocar nada de este archivo.
 */
public class TheStalkerEntityModel extends BipedEntityModel<TheStalkerEntity> {

	public TheStalkerEntityModel(ModelPart root) {
		super(root);
	}

	public static TexturedModelData getTexturedModelData() {
		return BipedEntityModel.getModelData(Dilation.NONE, 0.0F);
	}

	@Override
	public void setAngles(TheStalkerEntity entity, float limbAngle, float limbDistance,
						   float animationProgress, float headYaw, float headPitch) {
		super.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);
		// Punto de extension: aqui se podrian anadir poses propias (p.ej. inclinar
		// la cabeza mientras acecha) si mas adelante quieres afinar la animacion.
	}
}
