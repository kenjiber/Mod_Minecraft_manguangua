package com.manguangua.thestalker.client.render;

import com.manguangua.thestalker.TheStalker;
import com.manguangua.thestalker.entity.TheStalkerEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

/**
 * Renderer de TheStalker. Solo necesitas sustituir el archivo
 * assets/thestalker/textures/entity/thestalker.png (64x64, formato de
 * skin clasico) por tu propia textura; esta clase no necesita cambios.
 */
public class TheStalkerEntityRenderer extends MobEntityRenderer<TheStalkerEntity, TheStalkerEntityModel> {

	private static final Identifier TEXTURE = Identifier.of(TheStalker.MOD_ID, "textures/entity/thestalker.png");

	public TheStalkerEntityRenderer(EntityRendererFactory.Context context) {
		super(context, new TheStalkerEntityModel(context.getPart(
				com.manguangua.thestalker.client.TheStalkerClient.THE_STALKER_LAYER)), 0.5F);
	}

	@Override
	public Identifier getTexture(TheStalkerEntity entity) {
		return TEXTURE;
	}
}
