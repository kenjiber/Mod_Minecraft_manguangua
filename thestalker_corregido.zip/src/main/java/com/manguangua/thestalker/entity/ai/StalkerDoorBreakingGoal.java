package com.manguangua.thestalker.entity.ai;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.sound.StalkerSoundManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

/**
 * Detecta puertas (madera/hierro), trampillas y vallas cercanas (radio
 * configurable) que "bloquean el paso" hacia el jugador, se acerca y las
 * rompe a golpes (una vez por segundo, reproduciendo el sonido de golpe),
 * hasta destruirlas.
 * <p>
 * Prioridad MAS ALTA (numero mas bajo en el goalSelector) que
 * {@link StalkerBehaviorGoal}: mientras haya un obstaculo detectado, este
 * goal toma el control de movimiento/mirada; en cuanto ya no detecta
 * ninguno, {@code canStart()} devuelve false y el control vuelve al goal
 * principal automaticamente.
 */
public class StalkerDoorBreakingGoal extends Goal {

	private static final int DETECTION_RADIUS = 8;
	/** Golpes necesarios para tumbar una puerta/trampilla (configurable, pedido 5-10). */
	private static final int HITS_REQUIRED_DOOR = 7;
	/** Las vallas tardan mas en romperse (el doble de golpes). */
	private static final int HITS_REQUIRED_FENCE = 14;
	/** Un "golpe" cada 1 segundo (20 ticks), tal y como se pide en el diseno. */
	private static final int HIT_INTERVAL_TICKS = 20;
	/** Si no dropea items al romper el bloque (evita loot raro de puertas de hierro, etc). */
	private static final boolean DROP_BLOCK_ON_BREAK = false;

	private final TheStalkerEntity stalker;

	private BlockPos targetPos;
	private int hitsRequired;
	private int hitsLanded;
	private int hitCooldown;

	public StalkerDoorBreakingGoal(TheStalkerEntity stalker) {
		this.stalker = stalker;
		this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
	}

	@Override
	public boolean canStart() {
		if (!(this.stalker.getEntityWorld() instanceof ServerWorld)) {
			return false;
		}
		if (this.stalker.resolveTargetPlayer() == null) {
			return false;
		}
		BlockPos found = findNearestObstacle();
		if (found == null) {
			return false;
		}
		this.targetPos = found;
		Block block = this.stalker.getEntityWorld().getBlockState(found).getBlock();
		this.hitsRequired = isFence(block) ? HITS_REQUIRED_FENCE : HITS_REQUIRED_DOOR;
		this.hitsLanded = 0;
		return true;
	}

	@Override
	public boolean shouldContinue() {
		if (this.targetPos == null) {
			return false;
		}
		BlockState state = this.stalker.getEntityWorld().getBlockState(this.targetPos);
		return isBreakableObstacle(state.getBlock()) && this.hitsLanded < this.hitsRequired;
	}

	@Override
	public void start() {
		this.hitCooldown = 0;
	}

	@Override
	public void stop() {
		this.targetPos = null;
		this.stalker.getNavigation().stop();
	}

	@Override
	public void tick() {
		if (this.targetPos == null) {
			return;
		}
		Vec3d center = Vec3d.ofCenter(this.targetPos);
		this.stalker.getLookControl().lookAt(center.x, center.y, center.z);

		double distSq = this.stalker.getEntityPos().squaredDistanceTo(center);
		if (distSq > 4.5) {
			this.stalker.getNavigation().startMovingTo(center.x, center.y, center.z, 0.9);
			return;
		}

		this.stalker.getNavigation().stop();
		if (this.hitCooldown > 0) {
			this.hitCooldown--;
			return;
		}
		this.hitCooldown = HIT_INTERVAL_TICKS;
		this.hitsLanded++;
		this.stalker.swingHand(Hand.MAIN_HAND);
		StalkerSoundManager.playDoorBreak(this.stalker);

		if (this.hitsLanded >= this.hitsRequired) {
			breakObstacle();
		}
	}

	private void breakObstacle() {
		if (!(this.stalker.getEntityWorld() instanceof ServerWorld world) || this.targetPos == null) {
			return;
		}
		BlockState state = world.getBlockState(this.targetPos);
		Block block = state.getBlock();

		if (block instanceof DoorBlock && state.contains(Properties.DOUBLE_BLOCK_HALF)) {
			// Las puertas ocupan dos bloques (arriba/abajo): rompemos ambas mitades.
			boolean isLower = state.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.LOWER;
			BlockPos otherHalf = isLower ? this.targetPos.up() : this.targetPos.down();
			world.breakBlock(this.targetPos, DROP_BLOCK_ON_BREAK, this.stalker);
			if (world.getBlockState(otherHalf).getBlock() instanceof DoorBlock) {
				world.breakBlock(otherHalf, DROP_BLOCK_ON_BREAK, this.stalker);
			}
		} else {
			world.breakBlock(this.targetPos, DROP_BLOCK_ON_BREAK, this.stalker);
		}
		this.targetPos = null;
	}

	private BlockPos findNearestObstacle() {
		BlockPos origin = this.stalker.getBlockPos();
		BlockPos best = null;
		long bestDist = Long.MAX_VALUE;

		BlockPos start = origin.add(-DETECTION_RADIUS, -1, -DETECTION_RADIUS);
		BlockPos end = origin.add(DETECTION_RADIUS, 2, DETECTION_RADIUS);
		for (BlockPos pos : BlockPos.iterate(start, end)) {
			BlockState state = this.stalker.getEntityWorld().getBlockState(pos);
			if (isBreakableObstacle(state.getBlock()) && isClosed(state)) {
				long d = pos.getSquaredDistance(origin);
				if (d < bestDist) {
					bestDist = d;
					best = pos.toImmutable();
				}
			}
		}
		return best;
	}

	private static boolean isBreakableObstacle(Block block) {
		return block instanceof DoorBlock || block instanceof TrapdoorBlock || isFence(block);
	}

	private static boolean isFence(Block block) {
		return block instanceof FenceBlock || block instanceof FenceGateBlock;
	}

	/** Solo nos interesan las puertas/trampillas CERRADAS (una abierta no es un obstaculo). */
	private static boolean isClosed(BlockState state) {
		if (state.contains(Properties.OPEN)) {
			return !state.get(Properties.OPEN);
		}
		// Las vallas normales (no verjas) no tienen estado abierto/cerrado: siempre son un obstaculo.
		return true;
	}
}
