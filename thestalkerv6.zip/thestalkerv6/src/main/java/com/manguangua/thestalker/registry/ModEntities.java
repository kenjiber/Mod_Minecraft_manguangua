package com.manguangua.thestalker.registry;

import com.manguangua.thestalker.TheStalker;
import com.manguangua.thestalker.entity.TheStalkerEntity;
import net.fabricmc.fabric.api.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public final class ModEntities {

    public static final RegistryKey<EntityType<?>> THE_STALKER_KEY = RegistryKey.of(
            RegistryKeys.ENTITY_TYPE,
            Identifier.of(TheStalker.MOD_ID, "the_stalker")
    );

    public static final EntityType<TheStalkerEntity> THE_STALKER = Registry.register(
            Registries.ENTITY_TYPE,
            THE_STALKER_KEY,
            EntityType.Builder.create(SpawnGroup.MONSTER, TheStalkerEntity::new)
                    .dimensions(0.6f, 1.8f)
                    .maxTrackingRange(128)
                    .trackingTickInterval(2)
                    .build(THE_STALKER_KEY)
    );

    private ModEntities() {}

    public static void register() {
        FabricDefaultAttributeRegistry.register(THE_STALKER, TheStalkerEntity.createStalkerAttributes());
        TheStalker.LOGGER.info("[TheStalker] Entidad registrada.");
    }
}