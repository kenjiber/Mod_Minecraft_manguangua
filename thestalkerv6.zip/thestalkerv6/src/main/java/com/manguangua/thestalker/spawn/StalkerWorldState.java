package com.manguangua.thestalker.spawn;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.datafixer.DataFixTypes; // ✅ CORREGIDO: antes estaba en net.minecraft.util.datafix
import net.minecraft.nbt.NbtOps;
import net.minecraft.world.PersistentState;

import java.util.Optional;
import java.util.UUID;

public class StalkerWorldState extends PersistentState {

    private boolean firstSpawnDone;
    private long nextSpawnCheckTime;
    private UUID targetPlayerUuid;
    private UUID stalkerEntityUuid;

    public static final Codec<StalkerWorldState> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.fieldOf("firstSpawnDone").forGetter(s -> s.firstSpawnDone),
            Codec.LONG.fieldOf("nextSpawnCheckTime").forGetter(s -> s.nextSpawnCheckTime),
            // ✅ CORREGIDO: Uuids.CODEC fue eliminado. Usamos Codec.STRING con mapeo manual.
            Codec.STRING.xmap(UUID::fromString, UUID::toString).optionalFieldOf("targetPlayerUuid").forGetter(s -> Optional.ofNullable(s.targetPlayerUuid)),
            Codec.STRING.xmap(UUID::fromString, UUID::toString).optionalFieldOf("stalkerEntityUuid").forGetter(s -> Optional.ofNullable(s.stalkerEntityUuid))
    ).apply(instance, StalkerWorldState::new));

    private StalkerWorldState(boolean firstSpawnDone, long nextSpawnCheckTime,
                               Optional<UUID> targetPlayerUuid, Optional<UUID> stalkerEntityUuid) {
        this.firstSpawnDone = firstSpawnDone;
        this.nextSpawnCheckTime = nextSpawnCheckTime;
        this.targetPlayerUuid = targetPlayerUuid.orElse(null);
        this.stalkerEntityUuid = stalkerEntityUuid.orElse(null);
    }

    public StalkerWorldState() {
        this(false, 6000L, Optional.empty(), Optional.empty());
    }

    public static final Type<StalkerWorldState> TYPE = new Type<>(
            StalkerWorldState::new,
            (nbt, registryLookup) -> CODEC.parse(NbtOps.INSTANCE, nbt).result().orElseGet(StalkerWorldState::new),
            DataFixTypes.LEVEL
    );

    public boolean isFirstSpawnDone() {
        return this.firstSpawnDone;
    }

    public void setFirstSpawnDone(boolean value) {
        this.firstSpawnDone = value;
        this.markDirty();
    }

    public long getNextSpawnCheckTime() {
        return this.nextSpawnCheckTime;
    }

    public void setNextSpawnCheckTime(long ticks) {
        this.nextSpawnCheckTime = ticks;
        this.markDirty();
    }

    public UUID getTargetPlayerUuid() {
        return this.targetPlayerUuid;
    }

    public void setTargetPlayerUuid(UUID uuid) {
        this.targetPlayerUuid = uuid;
        this.markDirty();
    }

    public UUID getStalkerEntityUuid() {
        return this.stalkerEntityUuid;
    }

    public void setStalkerEntityUuid(UUID uuid) {
        this.stalkerEntityUuid = uuid;
        this.markDirty();
    }

    public void resetAll() {
        this.firstSpawnDone = false;
        this.nextSpawnCheckTime = 6000L;
        this.targetPlayerUuid = null;
        this.stalkerEntityUuid = null;
        this.markDirty();
    }
}