package com.manguangua.thestalker.entity;

import com.manguangua.thestalker.entity.ai.StalkerBehaviorGoal;
import com.manguangua.thestalker.entity.ai.StalkerDoorBreakingGoal;
import com.manguangua.thestalker.entity.ai.StalkerChestReviewGoal;
import com.manguangua.thestalker.registry.ModEntities;
import net.minecraft.entity.ContainerUser;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import net.minecraft.util.Uuids;
import net.minecraft.block.entity.ViewerCountManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.UUID;

/**
 * La entidad "TheStalker" / El Manguangua.
 *
 * Esta clase deliberadamente NO usa el sistema vanilla de "target" /
 * TargetGoal: el jugador objetivo se resuelve manualmente.
 *
 * Toda la logica de movimiento/acecho/persecucion vive en
 * StalkerBehaviorGoal; esta clase solo guarda estado y expone
 * utilidades pequenas.
 */
public class TheStalkerEntity extends HostileEntity implements ContainerUser {

	private static final String KEY_HAS_BEEN_HIT = "HasBeenHit";
	private static final String KEY_TARGET_UUID = "TargetPlayerUuid";
	private static final String KEY_LAST_KNOWN_X = "LastKnownX";
	private static final String KEY_LAST_KNOWN_Y = "LastKnownY";
	private static final String KEY_LAST_KNOWN_Z = "LastKnownZ";
	private static final String KEY_HAS_LAST_KNOWN = "HasLastKnownPos";
	private static final String KEY_HAS_REACHED_PLAYER = "HasReachedPlayer";

	/** true en cuanto el jugador lo golpea por primera vez. */
	private boolean hasBeenHit = false;

	/** UUID del jugador objetivo. */
	private UUID targetPlayerUuid;

	/** Ultima posicion conocida del jugador objetivo. */
	private Vec3d lastKnownPlayerPos;
	private boolean hasLastKnownPos = false;

	/** true despues de la primera aproximacion al jugador. */
	private boolean hasReachedPlayer = false;

	/** Referencia al goal principal. */
	private StalkerBehaviorGoal behaviorGoal;

	public TheStalkerEntity(EntityType<? extends HostileEntity> entityType, World world) {
		super(entityType, world);

		// Nunca se elimina por estar lejos del jugador ni por limpieza de mobs.
		this.setPersistent();
	}

	/** Atributos base. */
	public static DefaultAttributeContainer.Builder createStalkerAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.MAX_HEALTH, 20.0)
				.add(EntityAttributes.MOVEMENT_SPEED, 0.24)
				.add(EntityAttributes.ATTACK_DAMAGE, 6.0)
				.add(EntityAttributes.ATTACK_KNOCKBACK, 0.3)
				.add(EntityAttributes.FOLLOW_RANGE, 128.0)
				.add(EntityAttributes.STEP_HEIGHT, 1.0);
	}

	@Override
	protected void initGoals() {
		// Prioridad 0: nadar si cae al agua.
		this.goalSelector.add(0, new SwimGoal(this));

		// Prioridad 1: romper puertas/trampillas/vallas que bloqueen el paso.
		this.goalSelector.add(1, new StalkerDoorBreakingGoal(this));

		// Prioridad 2: revision de cofres dentro de casas.
		this.goalSelector.add(2, new StalkerChestReviewGoal(this));

		// Prioridad 3: comportamiento principal.
		this.behaviorGoal = new StalkerBehaviorGoal(this);
		this.goalSelector.add(3, this.behaviorGoal);

		// Prioridad 8: mirar alrededor cuando esta ocioso.
		this.goalSelector.add(8, new LookAroundGoal(this));

		// No se registra ningun TargetGoal.
	}

	/**
	 * Resuelve el jugador al que hay que perseguir:
	 * 1) El jugador objetivo guardado, si sigue conectado.
	 * 2) Si no, el jugador vivo mas cercano.
	 */
	public PlayerEntity resolveTargetPlayer() {
		if (!(this.getEntityWorld() instanceof ServerWorld serverWorld)) {
			return null;
		}

		if (this.targetPlayerUuid != null) {
			PlayerEntity saved = serverWorld.getPlayerByUuid(this.targetPlayerUuid);

			if (saved != null && saved.isAlive() && !saved.isSpectator()) {
				return saved;
			}
		}

		// Fallback: jugador vivo mas cercano.
		return serverWorld.getClosestPlayer(this, -1.0D);
	}

	public void setTargetPlayer(UUID uuid) {
		this.targetPlayerUuid = uuid;
	}

	public UUID getTargetPlayerUuid() {
		return this.targetPlayerUuid;
	}

	public boolean hasBeenHit() {
		return this.hasBeenHit;
	}

	/** Se llama desde StalkerBehaviorGoal cuando recibe el primer golpe. */
	public void markAsHit() {
		this.hasBeenHit = true;
	}

	public void updateLastKnownPlayerPos(Vec3d pos) {
		this.lastKnownPlayerPos = pos;
		this.hasLastKnownPos = true;
	}

	public Vec3d getLastKnownPlayerPos() {
		return this.lastKnownPlayerPos;
	}

	public boolean hasLastKnownPlayerPos() {
		return this.hasLastKnownPos;
	}

	public boolean hasReachedPlayer() {
		return this.hasReachedPlayer;
	}

	public void markReachedPlayer() {
		this.hasReachedPlayer = true;
	}

	@Override
	public double getContainerInteractionRange() {
		return 3.5D;
	}

	@Override
	public boolean isViewingContainerAt(ViewerCountManager viewerCountManager, BlockPos pos) {
		return this.squaredDistanceTo(
				pos.getX() + 0.5D,
				pos.getY() + 0.5D,
				pos.getZ() + 0.5D
		) <= this.getContainerInteractionRange() * this.getContainerInteractionRange();
	}

	@Override
	public boolean isInSneakingPose() {
		return !this.hasReachedPlayer;
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		// Nunca despawnea por distancia.
		return false;
	}

	@Override
	public void writeCustomData(WriteView view) {
		super.writeCustomData(view);

		view.putBoolean(KEY_HAS_BEEN_HIT, this.hasBeenHit);
		view.putBoolean(KEY_HAS_REACHED_PLAYER, this.hasReachedPlayer);

		if (this.targetPlayerUuid != null) {
			view.put(KEY_TARGET_UUID, Uuids.CODEC, this.targetPlayerUuid);
		}

		if (this.hasLastKnownPos && this.lastKnownPlayerPos != null) {
			view.putBoolean(KEY_HAS_LAST_KNOWN, true);
			view.putDouble(KEY_LAST_KNOWN_X, this.lastKnownPlayerPos.x);
			view.putDouble(KEY_LAST_KNOWN_Y, this.lastKnownPlayerPos.y);
			view.putDouble(KEY_LAST_KNOWN_Z, this.lastKnownPlayerPos.z);
		}
	}

	@Override
	public void readCustomData(ReadView view) {
		super.readCustomData(view);

		this.hasBeenHit = view.getBoolean(KEY_HAS_BEEN_HIT, false);
		this.hasReachedPlayer = view.getBoolean(KEY_HAS_REACHED_PLAYER, false);

		this.targetPlayerUuid = view
				.read(KEY_TARGET_UUID, Uuids.CODEC)
				.orElse(null);

		if (view.getBoolean(KEY_HAS_LAST_KNOWN, false)) {
			this.lastKnownPlayerPos = new Vec3d(
					view.getDouble(KEY_LAST_KNOWN_X, 0.0),
					view.getDouble(KEY_LAST_KNOWN_Y, 0.0),
					view.getDouble(KEY_LAST_KNOWN_Z, 0.0)
			);

			this.hasLastKnownPos = true;
		}
	}

	@Override
	protected void mobTick(ServerWorld world) {
		super.mobTick(world);

		// El cambio de agachado a erguido se comprueba desde el tick de la
		// entidad y no solo desde el Goal. Asi tambien funciona mientras el
		// Goal de romper puertas tiene el control del movimiento.
		PlayerEntity target = this.resolveTargetPlayer();
		if (!this.hasReachedPlayer && target != null
				&& this.distanceTo(target) <= 8.0D) {
			this.markReachedPlayer();
		}

		this.setPose(
				this.hasReachedPlayer
						? EntityPose.STANDING
						: EntityPose.CROUCHING
		);

		com.manguangua.thestalker.sound.StalkerSoundManager.tick(this);
	}

	@Override
	public boolean damage(ServerWorld world, DamageSource source, float amount) {
		boolean result = super.damage(world, source, amount);

		if (result
				&& !this.hasBeenHit
				&& source.getAttacker() instanceof PlayerEntity) {

			this.markAsHit();

			if (this.behaviorGoal != null) {
				// Inicia la huida de 10-15s con sonido de desesperacion.
				this.behaviorGoal.notifyHit(true);
			}
		}

		return result;
	}

	@Override
	public boolean tryAttack(ServerWorld world, net.minecraft.entity.Entity target) {
		// Antes del primer golpe del jugador, el Stalker JAMAS hace dano.
		if (!this.hasBeenHit) {
			return false;
		}

		return super.tryAttack(world, target);
	}

	@Override
	public void onDeath(DamageSource damageSource) {
		super.onDeath(damageSource);

		if (this.getEntityWorld() instanceof ServerWorld serverWorld) {
			// Libera el slot de Stalker vivo en el estado del mundo.
			com.manguangua.thestalker.spawn.StalkerSpawnHandler.onStalkerDied(
					serverWorld,
					this.getUuid()
			);
		}
	}

	/** Fabrica de spawn usada por el comando /thestalker spawn y por el spawn automatico. */
	public static TheStalkerEntity create(ServerWorld world) {
		return ModEntities.THE_STALKER.create(world, SpawnReason.MOB_SUMMONED);
	}
}