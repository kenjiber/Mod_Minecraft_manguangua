package com.manguangua.thestalker.sound;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.registry.ModSounds;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;

/**
 * Centraliza la reproduccion de todos los sonidos de la entidad.
 * <p>
 * Usamos {@code World#playSound(null, x, y, z, sound, category, volume, pitch)}
 * (sonido posicional, servidor -> todos los clientes cercanos). El volumen
 * "percibido" ya varia con la distancia automaticamente porque el motor de
 * audio del cliente atenua los sonidos posicionales segun donde este la
 * camara del jugador; aqui solo variamos un poco el pitch para que no suene
 * repetitivo.
 */
public final class StalkerSoundManager {

	/**
	 * Probabilidad de que, al tocar sonido ambiente, suene "quemanguangua.ogg"
	 * (registrado como STALKER_AMBIENT_PRIMARY) en vez de una de las otras
	 * variantes. Pedido explicitamente: que sea, con diferencia, el audio
	 * que MAS se reproduce de toda la entidad. Sube/baja este numero (0.0-1.0)
	 * para ajustar que tan dominante es.
	 */
	private static final float AMBIENT_PRIMARY_CHANCE = 0.7F;

	private StalkerSoundManager() {
	}

	public static void playAmbient(TheStalkerEntity stalker, double distanceToPlayer) {
		if (stalker.getRandom().nextFloat() < AMBIENT_PRIMARY_CHANCE) {
			// quemanguangua.ogg: el sonido "estrella", suena la mayoria de las veces.
			play(stalker, ModSounds.STALKER_AMBIENT_PRIMARY, 1.0F);
		} else {
			// El resto de variantes, para que no sea 100% repetitivo.
			play(stalker, ModSounds.STALKER_AMBIENT, 1.0F);
		}
	}

	public static void playDespair(TheStalkerEntity stalker) {
		play(stalker, ModSounds.STALKER_DESPAIR, 1.0F);
	}

	public static void playSpawn(TheStalkerEntity stalker) {
		play(stalker, ModSounds.STALKER_SPAWN, 1.0F);
	}

	public static void playStare(TheStalkerEntity stalker) {
		play(stalker, ModSounds.STALKER_STARE, 1.0F);
	}

	public static void playDoorBreak(TheStalkerEntity stalker) {
		play(stalker, ModSounds.STALKER_DOOR_BREAK, 0.8F);
	}

	private static void play(TheStalkerEntity stalker, SoundEvent sound, float baseVolume) {
		float pitch = 0.9F + stalker.getRandom().nextFloat() * 0.2F;
		stalker.getEntityWorld().playSound(
				null,
				stalker.getX(), stalker.getY(), stalker.getZ(),
				sound,
				SoundCategory.HOSTILE,
				baseVolume,
				pitch
		);
	}
}
