package com.tuusuario.modrealista.init;

import com.tuusuario.modrealista.block.entity.AltoHornoBlockEntity;
import com.tuusuario.modrealista.block.entity.FusionFurnaceBlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import static com.tuusuario.modrealista.ModRealista.MOD_ID;

public final class ModBlockEntities {

	private ModBlockEntities() {}

	public static BlockEntityType<AltoHornoBlockEntity> ALTO_HORNO_ENTITY;
	public static BlockEntityType<FusionFurnaceBlockEntity> HORNO_FUSION_BASICO_ENTITY;
	public static BlockEntityType<FusionFurnaceBlockEntity> HORNO_FUSION_AVANZADO_ENTITY;

	public static void registrarTodo() {
		ALTO_HORNO_ENTITY = Registries.BLOCK_ENTITY_TYPE.add(
				RegistryKey.of(RegistryKeys.BLOCK_ENTITY_TYPE, Identifier.of(MOD_ID, "alto_horno_de_cobre")),
				BlockEntityType.Builder.create(
						AltoHornoBlockEntity::new,
						ModBlocks.ALTO_HORNO_DE_COBRE
				).build());

		HORNO_FUSION_BASICO_ENTITY = Registries.BLOCK_ENTITY_TYPE.add(
				RegistryKey.of(RegistryKeys.BLOCK_ENTITY_TYPE, Identifier.of(MOD_ID, "horno_fusion_basico")),
				BlockEntityType.Builder.create(
						(pos, state) -> new FusionFurnaceBlockEntity(pos, state, 1),
						ModBlocks.HORNO_DE_FUSION_BASICO
				).build());

		HORNO_FUSION_AVANZADO_ENTITY = Registries.BLOCK_ENTITY_TYPE.add(
				RegistryKey.of(RegistryKeys.BLOCK_ENTITY_TYPE, Identifier.of(MOD_ID, "horno_fusion_avanzado")),
				BlockEntityType.Builder.create(
						(pos, state) -> new FusionFurnaceBlockEntity(pos, state, 2),
						ModBlocks.HORNO_DE_FUSION_AVANZADO
				).build());
	}
}
