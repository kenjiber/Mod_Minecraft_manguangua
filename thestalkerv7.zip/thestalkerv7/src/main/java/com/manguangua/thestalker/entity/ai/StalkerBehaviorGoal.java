package com.manguangua.thestalker.entity.ai;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.sound.StalkerSoundManager;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

public class StalkerBehaviorGoal extends Goal {

    private static final double CHASE_DISTANCE_THRESHOLD = 18.0;
    private static final double FLEE_DISTANCE_MIN = 20.0;
    private static final double FLEE_DISTANCE_MAX = 30.0;
    private static final int FIRST_HIT_FLEE_TICKS_MIN = 200;
    private static final int FIRST_HIT_FLEE_TICKS_MAX = 300;
    private static final int POST_ATTACK_FLEE_TICKS_MIN = 60;
    private static final int POST_ATTACK_FLEE_TICKS_MAX = 100;
    private static final int TICKS_UNTIL_LOST = 100;
    private static final double PATROL_RADIUS = 12.0;
    private static final double STARE_ANGLE_RADIANS = Math.toRadians(20.0);
    private static final double STARE_MAX_DISTANCE = 40.0;
    private static final int STARE_SOUND_COOLDOWN_TICKS = 100;
    private static final int AMBIENT_COOLDOWN_MIN = 160;
    private static final int AMBIENT_COOLDOWN_MAX = 400;
    private static final double ATTACK_RANGE = 2.3;
    private static final int ATTACK_COOLDOWN_TICKS = 20;

    private static final double SPEED_STALKING = 0.55;
    private static final double SPEED_CHASING = 1.15;
    private static final double SPEED_CHASING_SPRINT = 1.35;
    private static final double SPEED_FLEEING = 1.25;
    private static final double SPEED_PATROLLING = 0.8;

    private final TheStalkerEntity stalker;
    private StalkerState state = StalkerState.STALKING;
    private int ticksSinceLastSeen = 0;
    private int fleeTicksRemaining = 0;
    private int ambientSoundCooldown = randomAmbientCooldown(null);
    private int stareSoundCooldown = 0;
    private int attackCooldown = 0;
    private boolean wasBeingWatchedLastTick = false;

    public StalkerBehaviorGoal(TheStalkerEntity stalker) {
        this.stalker = stalker;
        this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK, Goal.Control.JUMP));
    }

    @Override
    public boolean canStart() {
        return this.stalker.getEntityWorld() instanceof ServerWorld && this.stalker.resolveTargetPlayer() != null;
    }

    @Override
    public boolean shouldContinue() {
        return this.canStart();
    }

    @Override
    public void start() {
        this.state = StalkerState.STALKING;
    }

    @Override
    public void stop() {
        this.stalker.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (!(this.stalker.getEntityWorld() instanceof ServerWorld world)) {
            return;
        }
        PlayerEntity player = this.stalker.resolveTargetPlayer();
        if (player == null) return;

        double distance = this.stalker.distanceTo(player);
        
        // ✅ CORREGIDO: canSee() en lugar de getVisibilityCache().canSee()
        boolean canSee = this.stalker.canSee(player);

        if (this.attackCooldown > 0) this.attackCooldown--;

        if (canSee) {
            this.stalker.updateLastKnownPlayerPos(player.getPos());
            this.ticksSinceLastSeen = 0;
        } else {
            this.ticksSinceLastSeen++;
        }

        if (this.fleeTicksRemaining > 0) {
            this.state = StalkerState.FLEEING;
        } else if (canSee && this.ticksSinceLastSeen == 0) {
            boolean playerIsFast = player.isSprinting() || distance > CHASE_DISTANCE_THRESHOLD;
            this.state = playerIsFast ? StalkerState.CHASING : StalkerState.STALKING;
        } else if (this.ticksSinceLastSeen > TICKS_UNTIL_LOST) {
            this.state = StalkerState.PATROLLING;
        }

        boolean beingWatched = canSee && distance <= STARE_MAX_DISTANCE && isPlayerLookingAtStalker(player);
        if (this.stareSoundCooldown > 0) this.stareSoundCooldown--;
        if (beingWatched && !this.wasBeingWatchedLastTick && this.stareSoundCooldown <= 0) {
            StalkerSoundManager.playStare(this.stalker);
            this.stareSoundCooldown = STARE_SOUND_COOLDOWN_TICKS;
        }
        this.wasBeingWatchedLastTick = beingWatched;

        switch (this.state) {
            case STALKING -> tickStalking(player, beingWatched);
            case CHASING -> tickChasing(world, player, distance);
            case FLEEING -> tickFleeing(player);
            case PATROLLING -> tickPatrolling();
        }

        if (this.state == StalkerState.STALKING || this.state == StalkerState.CHASING) {
            this.ambientSoundCooldown--;
            if (this.ambientSoundCooldown <= 0) {
                StalkerSoundManager.playAmbient(this.stalker, distance);
                this.ambientSoundCooldown = randomAmbientCooldown(this.stalker);
            }
        }
    }

    public void notifyHit(boolean firstHitEver) {
        int min = firstHitEver ? FIRST_HIT_FLEE_TICKS_MIN : POST_ATTACK_FLEE_TICKS_MIN;
        int max = firstHitEver ? FIRST_HIT_FLEE_TICKS_MAX : POST_ATTACK_FLEE_TICKS_MAX;
        this.fleeTicksRemaining = min + this.stalker.getRandom().nextInt(max - min + 1);
        this.state = StalkerState.FLEEING;
        StalkerSoundManager.playDespair(this.stalker);
    }

    private void tickStalking(PlayerEntity player, boolean beingWatched) {
        this.stalker.getLookControl().lookAt(player, 30.0F, 30.0F);
        if (beingWatched) {
            this.stalker.getNavigation().stop();
            return;
        }
        this.stalker.getNavigation().startMovingTo(player, SPEED_STALKING);
    }

    private void tickChasing(ServerWorld world, PlayerEntity player, double distance) {
        this.stalker.getLookControl().lookAt(player, 30.0F, 30.0F);
        double speed = player.isSprinting() ? SPEED_CHASING_SPRINT : SPEED_CHASING;
        this.stalker.getNavigation().startMovingTo(player, speed);

        if (this.stalker.hasBeenHit() && distance <= ATTACK_RANGE && this.attackCooldown <= 0) {
            this.attackCooldown = ATTACK_COOLDOWN_TICKS;
            boolean hit = this.stalker.tryAttack(world, player);
            if (hit) this.notifyHit(false);
        }
    }

    private void tickFleeing(PlayerEntity player) {
        this.fleeTicksRemaining--;
        Vec3d away = computeFleePoint(player);
        this.stalker.getNavigation().startMovingTo(away.x, away.y, away.z, SPEED_FLEEING);
        this.stalker.getLookControl().lookAt(away.x, away.y, away.z);

        if (this.fleeTicksRemaining <= 0) {
            this.state = this.stalker.hasBeenHit() ? StalkerState.CHASING : StalkerState.STALKING;
        }
    }

    private void tickPatrolling() {
        if (!this.stalker.hasLastKnownPlayerPos()) return;
        Vec3d lastKnown = this.stalker.getLastKnownPlayerPos();
        if (this.stalker.getNavigation().isIdle()) {
            double offsetX = (this.stalker.getRandom().nextDouble() - 0.5) * 2.0 * PATROL_RADIUS;
            double offsetZ = (this.stalker.getRandom().nextDouble() - 0.5) * 2.0 * PATROL_RADIUS;
            this.stalker.getNavigation().startMovingTo(lastKnown.x + offsetX, lastKnown.y, lastKnown.z + offsetZ, SPEED_PATROLLING);
        }
    }

    private Vec3d computeFleePoint(PlayerEntity player) {
        Vec3d fromPlayerToStalker = this.stalker.getPos().subtract(player.getPos());
        if (fromPlayerToStalker.lengthSquared() < 0.01) {
            double angle = this.stalker.getRandom().nextDouble() * Math.PI * 2;
            fromPlayerToStalker = new Vec3d(Math.cos(angle), 0, Math.sin(angle));
        }
        Vec3d direction = fromPlayerToStalker.normalize();
        double distance = FLEE_DISTANCE_MIN + this.stalker.getRandom().nextDouble() * (FLEE_DISTANCE_MAX - FLEE_DISTANCE_MIN);
        return player.getPos().add(direction.multiply(distance));
    }

    private boolean isPlayerLookingAtStalker(PlayerEntity player) {
        Vec3d lookDirection = player.getRotationVec(1.0F);
        Vec3d toStalker = this.stalker.getEyePos().subtract(player.getEyePos()).normalize();
        // ✅ CORREGIDO: Cálculo manual para evitar errores de dotProduct
        double dot = lookDirection.x * toStalker.x + lookDirection.y * toStalker.y + lookDirection.z * toStalker.z;
        // ✅ CORREGIDO: MathHelper.clamp en lugar de Math.clamp
        double angle = Math.acos(MathHelper.clamp(dot, -1.0, 1.0));
        return angle <= STARE_ANGLE_RADIANS;
    }

    private static int randomAmbientCooldown(TheStalkerEntity stalker) {
        int range = AMBIENT_COOLDOWN_MAX - AMBIENT_COOLDOWN_MIN;
        if (stalker == null) return AMBIENT_COOLDOWN_MIN + (int) (Math.random() * range);
        return AMBIENT_COOLDOWN_MIN + stalker.getRandom().nextInt(range + 1);
    }
}