package com.manguangua.thestalker.registry;

import com.manguangua.thestalker.TheStalker;
import com.manguangua.thestalker.entity.TheStalkerEntity;
import net.fabricmc.fabric.api.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

/**
 * Registro del EntityType de TheStalker.
 * <p>
 * NOTA DE VERSION: en 1.21.x, EntityType.Builder#build(...) espera una
 * RegistryKey<EntityType<?>> (ya no un String plano). Si tu version exacta
 * de Minecraft cambia esta firma, este es el unico lugar que deberias
 * necesitar tocar.
 */
public final class ModEntities {

	public static final RegistryKey<EntityType<?>> THE_STALKER_KEY = RegistryKey.of(
			RegistryKeys.ENTITY_TYPE,
			Identifier.of(TheStalker.MOD_ID, "the_stalker")
	);

	public static final EntityType<TheStalkerEntity> THE_STALKER = Registry.register(
			Registries.ENTITY_TYPE,
			THE_STALKER_KEY,
			FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, TheStalkerEntity::new)
					.dimensions(EntityDimensions.fixed(0.6f, 1.8f))
					// Rango de seguimiento grande: el Stalker "recuerda" al jugador
					// aunque este muy lejos (la logica de objetivo es 100% manual,
					// ver TheStalkerEntity / StalkerBehaviorGoal).
					.trackRangeBlocks(128)
					.trackedUpdateRate(2)
					.build(THE_STALKER_KEY)
	);

	private ModEntities() {
	}

	/** Llamado una vez desde TheStalker#onInitialize(). */
	public static void register() {
		FabricDefaultAttributeRegistry.register(THE_STALKER, TheStalkerEntity.createStalkerAttributes());
		TheStalker.LOGGER.info("[TheStalker] Entidad registrada.");
	}
}
