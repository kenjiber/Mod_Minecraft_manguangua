package com.manguangua.thestalker.entity;

import com.manguangua.thestalker.entity.ai.StalkerBehaviorGoal;
import com.manguangua.thestalker.entity.ai.StalkerDoorBreakingGoal;
import com.manguangua.thestalker.registry.ModEntities;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.UUID;

/**
 * La entidad "TheStalker" / El Manguangua.
 * <p>
 * Esta clase deliberadamente NO usa el sistema vanilla de "target" /
 * TargetGoal: el jugador objetivo se resuelve manualmente (ver
 * {@link #resolveTargetPlayer()}) porque el requisito es "solo persigue
 * a UN jugador concreto", no "ataca al enemigo mas cercano que cumpla X".
 * Toda la logica de movimiento/acecho/persecucion vive en
 * {@link StalkerBehaviorGoal}; esta clase solo guarda estado y expone
 * utilidades pequenas.
 *
 * <p><b>NOTA DE VERSION (1.21.11):</b> la firma de {@link #damage} incluye
 * un {@link ServerWorld} como primer parametro (cambio introducido en la
 * linea 1.21.x). Si tu IDE marca esta firma como "no sobreescribe nada",
 * pulsa "Generate > Override Methods" sobre {@code damage} para ver la
 * firma exacta de tu version y ajusta esta clase.
 */
public class TheStalkerEntity extends HostileEntity {

	private static final String KEY_HAS_BEEN_HIT = "HasBeenHit";
	private static final String KEY_TARGET_UUID = "TargetPlayerUuid";
	private static final String KEY_LAST_KNOWN_X = "LastKnownX";
	private static final String KEY_LAST_KNOWN_Y = "LastKnownY";
	private static final String KEY_LAST_KNOWN_Z = "LastKnownZ";
	private static final String KEY_HAS_LAST_KNOWN = "HasLastKnownPos";

	/** true en cuanto el jugador lo golpea por primera vez (a partir de ahi, el puede hacer dano). */
	private boolean hasBeenHit = false;

	/** UUID del jugador "objetivo" (el que creo el mundo / el que estaba mas cerca en el primer spawn). */
	private UUID targetPlayerUuid;

	/** Ultima posicion conocida del jugador objetivo (para patrullar cuando lo pierde de vista). */
	private Vec3d lastKnownPlayerPos;
	private boolean hasLastKnownPos = false;

	/** Referencia al goal principal, para poder avisarle del primer golpe desde damage(). */
	private StalkerBehaviorGoal behaviorGoal;

	public TheStalkerEntity(EntityType<? extends HostileEntity> entityType, World world) {
		super(entityType, world);
		// Nunca se elimina por estar lejos del jugador ni por limpieza de mobs.
		this.setPersistent();
	}

	/** Atributos base. Llamado desde ModEntities al registrar el EntityType. */
	public static DefaultAttributeContainer.Builder createStalkerAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.MAX_HEALTH, 20.0)
				// Velocidad "base"; los multiplicadores de acecho/persecucion
				// se aplican en StalkerBehaviorGoal via getNavigation().startMovingTo(..., speed).
				.add(EntityAttributes.MOVEMENT_SPEED, 0.24)
				.add(EntityAttributes.ATTACK_DAMAGE, 6.0)
				.add(EntityAttributes.ATTACK_KNOCKBACK, 0.3)
				.add(EntityAttributes.FOLLOW_RANGE, 128.0)
				.add(EntityAttributes.STEP_HEIGHT, 1.0);
	}

	@Override
	protected void initGoals() {
		// Prioridad 0: nadar si cae al agua (evita que se ahogue tontamente).
		this.goalSelector.add(0, new SwimGoal(this));
		// Prioridad 1: si hay una puerta/trampilla/valla cerca bloqueando el paso, la rompe.
		// Va ANTES que el goal principal a proposito: StalkerBehaviorGoal casi siempre
		// puede "iniciarse" (solo necesita un jugador resoluble), asi que si tuviera
		// prioridad mas alta nunca cederia el control a este goal.
		this.goalSelector.add(1, new StalkerDoorBreakingGoal(this));
		// Prioridad 2: comportamiento principal (acecho / persecucion / huida / patrulla).
		this.behaviorGoal = new StalkerBehaviorGoal(this);
		this.goalSelector.add(2, this.behaviorGoal);
		// Prioridad 8: mirar alrededor quando esta ocioso (patrullando).
		this.goalSelector.add(8, new LookAroundGoal(this));
		// Nota: a proposito NO se registra ningun TargetGoal en targetSelector.
		// El objetivo se resuelve a mano en resolveTargetPlayer().
	}

	/**
	 * Resuelve el jugador al que hay que perseguir:
	 * 1) El jugador "objetivo" guardado (el que creo el mundo / primer spawn), si sigue conectado.
	 * 2) Si no, el jugador vivo mas cercano en este mundo (fallback pedido en el requisito).
	 */
	public PlayerEntity resolveTargetPlayer() {
		if (!(this.getWorld() instanceof ServerWorld serverWorld)) {
			return null;
		}

		if (this.targetPlayerUuid != null) {
			PlayerEntity saved = serverWorld.getPlayerByUuid(this.targetPlayerUuid);
			if (saved != null && saved.isAlive() && !saved.isSpectator()) {
				return saved;
			}
		}

		// Fallback: jugador vivo mas cercano (ignorando espectadores).
		return serverWorld.getClosestPlayer(this, -1.0D);
	}

	public void setTargetPlayer(UUID uuid) {
		this.targetPlayerUuid = uuid;
	}

	public UUID getTargetPlayerUuid() {
		return this.targetPlayerUuid;
	}

	public boolean hasBeenHit() {
		return this.hasBeenHit;
	}

	/** Se llama desde StalkerBehaviorGoal cuando detecta el primer golpe recibido. */
	public void markAsHit() {
		this.hasBeenHit = true;
	}

	public void updateLastKnownPlayerPos(Vec3d pos) {
		this.lastKnownPlayerPos = pos;
		this.hasLastKnownPos = true;
	}

	public Vec3d getLastKnownPlayerPos() {
		return this.lastKnownPlayerPos;
	}

	public boolean hasLastKnownPlayerPos() {
		return this.hasLastKnownPos;
	}

	@Override
	public boolean canImmediatelyDespawn(double distanceSquared) {
		// Nunca despawnea por distancia: es una entidad persistente por diseno.
		return false;
	}

	@Override
	public void writeCustomDataToNbt(NbtCompound nbt) {
		super.writeCustomDataToNbt(nbt);
		nbt.putBoolean(KEY_HAS_BEEN_HIT, this.hasBeenHit);
		if (this.targetPlayerUuid != null) {
			nbt.putUuid(KEY_TARGET_UUID, this.targetPlayerUuid);
		}
		if (this.hasLastKnownPos && this.lastKnownPlayerPos != null) {
			nbt.putBoolean(KEY_HAS_LAST_KNOWN, true);
			nbt.putDouble(KEY_LAST_KNOWN_X, this.lastKnownPlayerPos.x);
			nbt.putDouble(KEY_LAST_KNOWN_Y, this.lastKnownPlayerPos.y);
			nbt.putDouble(KEY_LAST_KNOWN_Z, this.lastKnownPlayerPos.z);
		}
	}

	@Override
	public void readCustomDataFromNbt(NbtCompound nbt) {
		super.readCustomDataFromNbt(nbt);
		this.hasBeenHit = nbt.getBoolean(KEY_HAS_BEEN_HIT);
		if (nbt.contains(KEY_TARGET_UUID)) {
			this.targetPlayerUuid = nbt.getUuid(KEY_TARGET_UUID);
		}
		if (nbt.getBoolean(KEY_HAS_LAST_KNOWN)) {
			this.lastKnownPlayerPos = new Vec3d(
					nbt.getDouble(KEY_LAST_KNOWN_X),
					nbt.getDouble(KEY_LAST_KNOWN_Y),
					nbt.getDouble(KEY_LAST_KNOWN_Z)
			);
			this.hasLastKnownPos = true;
		}
	}

	@Override
	public boolean damage(ServerWorld world, DamageSource source, float amount) {
		boolean result = super.damage(world, source, amount);
		if (result && !this.hasBeenHit && source.getAttacker() instanceof PlayerEntity) {
			this.markAsHit();
			if (this.behaviorGoal != null) {
				// Inicia la huida de 10-15s con sonido de "desesperacion" (ver StalkerBehaviorGoal).
				this.behaviorGoal.notifyHit(true);
			}
		}
		return result;
	}

	@Override
	public boolean tryAttack(ServerWorld world, net.minecraft.entity.Entity target) {
		// Antes del primer golpe del jugador, el Stalker JAMAS hace dano,
		// aunque este a distancia de golpeo (requisito explicito del diseno).
		if (!this.hasBeenHit) {
			return false;
		}
		return super.tryAttack(world, target);
	}

	@Override
	public void onDeath(DamageSource damageSource) {
		super.onDeath(damageSource);
		if (this.getWorld() instanceof ServerWorld serverWorld) {
			// Libera el "slot" de Stalker vivo en el estado del mundo, para que el
			// sistema de spawn pueda crear uno nuevo pasado un tiempo. Ver StalkerSpawnHandler.
			com.manguangua.thestalker.spawn.StalkerSpawnHandler.onStalkerDied(serverWorld, this.getUuid());
		}
	}

	/** Utilidad: fabrica de spawn usada por el comando /thestalker spawn y por el spawn automatico. */
	public static TheStalkerEntity create(ServerWorld world) {
		return ModEntities.THE_STALKER.create(world, SpawnReason.MOB_SUMMONED);
	}
}
