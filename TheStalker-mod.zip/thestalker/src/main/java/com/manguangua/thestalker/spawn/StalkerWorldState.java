package com.manguangua.thestalker.spawn;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.nbt.NbtOps;
import net.minecraft.util.Uuids;
import net.minecraft.world.PersistentState;

import java.util.Optional;
import java.util.UUID;

/**
 * Guarda, a nivel de MUNDO (no de entidad), todo lo necesario para el
 * sistema de spawn: si ya ocurrio el primer spawn (a los 5 minutos),
 * cuando toca el proximo spawn/reaparicion aleatoria, que jugador es el
 * "objetivo" y el UUID de la instancia actual del Stalker (para poder
 * localizarla de nuevo aunque el chunk se descargue).
 *
 * <p><b>NOTA DE VERSION IMPORTANTE:</b> Mojang cambio el sistema de
 * {@code PersistentState} a un modelo basado en {@code Codec} sobre
 * 1.20.5/1.21. Este archivo usa ese patron "moderno". Si tu version
 * exacta de 1.21.11 tiene una firma distinta para
 * {@code PersistentState.Type} o {@code PersistentStateManager#getOrCreate},
 * este es, con diferencia, el archivo con mas probabilidad de necesitar un
 * ajuste manual. Consulta:
 * https://docs.fabricmc.net/develop/data-storage/persistent-states
 * y adapta el patron de abajo (los 4 campos de datos no cambian, solo la
 * "fontaneria" de guardado/carga).
 */
public class StalkerWorldState extends PersistentState {

	/** true en cuanto ha ocurrido el spawn inicial (a los 6000 ticks del primer dia). */
	private boolean firstSpawnDone;
	/** Tiempo de mundo (world.getTime()) en el que toca el siguiente intento de spawn/reaparicion. */
	private long nextSpawnCheckTime;
	/** UUID del jugador "objetivo" (el que creo el mundo / el mas cercano en el primer spawn). */
	private UUID targetPlayerUuid;
	/** UUID de la entidad Stalker actualmente viva en este mundo (null si no existe ninguna). */
	private UUID stalkerEntityUuid;

	public static final Codec<StalkerWorldState> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.BOOL.fieldOf("firstSpawnDone").forGetter(s -> s.firstSpawnDone),
			Codec.LONG.fieldOf("nextSpawnCheckTime").forGetter(s -> s.nextSpawnCheckTime),
			Uuids.CODEC.optionalFieldOf("targetPlayerUuid").forGetter(s -> Optional.ofNullable(s.targetPlayerUuid)),
			Uuids.CODEC.optionalFieldOf("stalkerEntityUuid").forGetter(s -> Optional.ofNullable(s.stalkerEntityUuid))
	).apply(instance, StalkerWorldState::new));

	private StalkerWorldState(boolean firstSpawnDone, long nextSpawnCheckTime,
							   Optional<UUID> targetPlayerUuid, Optional<UUID> stalkerEntityUuid) {
		this.firstSpawnDone = firstSpawnDone;
		this.nextSpawnCheckTime = nextSpawnCheckTime;
		this.targetPlayerUuid = targetPlayerUuid.orElse(null);
		this.stalkerEntityUuid = stalkerEntityUuid.orElse(null);
	}

	public StalkerWorldState() {
		this(false, 6000L, Optional.empty(), Optional.empty());
	}

	public static final Type<StalkerWorldState> TYPE = new Type<>(
			StalkerWorldState::new,
			(nbt, registryLookup) -> CODEC.parse(NbtOps.INSTANCE, nbt).result().orElseGet(StalkerWorldState::new),
			null
	);

	// ===================== Getters / Setters =====================

	public boolean isFirstSpawnDone() {
		return this.firstSpawnDone;
	}

	public void setFirstSpawnDone(boolean value) {
		this.firstSpawnDone = value;
		this.markDirty();
	}

	public long getNextSpawnCheckTime() {
		return this.nextSpawnCheckTime;
	}

	public void setNextSpawnCheckTime(long ticks) {
		this.nextSpawnCheckTime = ticks;
		this.markDirty();
	}

	public UUID getTargetPlayerUuid() {
		return this.targetPlayerUuid;
	}

	public void setTargetPlayerUuid(UUID uuid) {
		this.targetPlayerUuid = uuid;
		this.markDirty();
	}

	public UUID getStalkerEntityUuid() {
		return this.stalkerEntityUuid;
	}

	public void setStalkerEntityUuid(UUID uuid) {
		this.stalkerEntityUuid = uuid;
		this.markDirty();
	}

	/** Reinicia TODO el estado (usado por /thestalker reset). */
	public void resetAll() {
		this.firstSpawnDone = false;
		this.nextSpawnCheckTime = 6000L;
		this.targetPlayerUuid = null;
		this.stalkerEntityUuid = null;
		this.markDirty();
	}
}
