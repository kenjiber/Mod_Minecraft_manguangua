package com.manguangua.thestalker.entity.ai;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.sound.StalkerSoundManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

/**
 * Persecucion persistente del jugador objetivo.
 *
 * El Stalker ya no pierde al jugador ni entra en patrulla: mientras el jugador
 * siga conectado y vivo, continua intentando llegar hasta el, incluso si
 * deja de verlo. Tambien puede construir una torre de tablones cuando el
 * jugador esta claramente por encima.
 */
public class StalkerBehaviorGoal extends Goal {

	private static final double APPROACH_CLOSE_DISTANCE = 8.0;
	private static final double CHASE_DISTANCE_THRESHOLD = 18.0;

	private static final double FLEE_DISTANCE_MIN = 20.0;
	private static final double FLEE_DISTANCE_MAX = 30.0;
	private static final int FIRST_HIT_FLEE_TICKS_MIN = 200;
	private static final int FIRST_HIT_FLEE_TICKS_MAX = 300;
	private static final int POST_ATTACK_FLEE_TICKS_MIN = 60;
	private static final int POST_ATTACK_FLEE_TICKS_MAX = 100;

	private static final double STARE_ANGLE_RADIANS = Math.toRadians(20.0);
	private static final double STARE_MAX_DISTANCE = 40.0;
	private static final int STARE_SOUND_COOLDOWN_TICKS = 100;

	private static final double ATTACK_RANGE = 2.3;
	private static final int ATTACK_COOLDOWN_TICKS = 20;

	private static final double SPEED_CHASING = 1.15;
	private static final double SPEED_CHASING_SPRINT = 1.35;
	private static final double SPEED_FLEEING = 1.25;

	/** Cada cuantos ticks como minimo intenta construir hacia arriba. */
	private static final int BUILD_COOLDOWN_TICKS = 10;
	private static final double BUILD_MIN_VERTICAL_ADVANTAGE = 1.5;

	private final TheStalkerEntity stalker;

	private StalkerState state = StalkerState.STALKING;
	private int fleeTicksRemaining = 0;
	private int stareSoundCooldown = 0;
	private int attackCooldown = 0;
	private int buildCooldown = 0;
	private int digCooldown = 0;
	private BlockPos diggingPos;
	private int ambientSoundCooldown;
	private boolean wasBeingWatchedLastTick = false;

	public StalkerBehaviorGoal(TheStalkerEntity stalker) {
		this.stalker = stalker;
		this.ambientSoundCooldown = StalkerSoundManager.nextAmbientCooldown(stalker);
		this.setControls(EnumSet.of(
				Goal.Control.MOVE,
				Goal.Control.LOOK,
				Goal.Control.JUMP
		));
	}

	@Override
	public boolean canStart() {
		return this.stalker.getEntityWorld() instanceof ServerWorld
				&& this.stalker.resolveTargetPlayer() != null;
	}

	@Override
	public boolean shouldContinue() {
		return this.canStart();
	}

	@Override
	public void start() {
		this.state = StalkerState.STALKING;
		// El Stalker siempre se mantiene erguido.
		this.stalker.setPose(net.minecraft.entity.EntityPose.STANDING);
	}

	@Override
	public void stop() {
		this.stalker.getNavigation().stop();
	}

	@Override
	public void tick() {
		if (!(this.stalker.getEntityWorld() instanceof ServerWorld world)) {
			return;
		}

		PlayerEntity player = this.stalker.resolveTargetPlayer();
		if (player == null) {
			return;
		}

		double distance = this.stalker.distanceTo(player);
		boolean canSee = this.stalker.canSee(player);

		if (this.attackCooldown > 0) {
			this.attackCooldown--;
		}
		if (this.stareSoundCooldown > 0) {
			this.stareSoundCooldown--;
		}
		if (this.buildCooldown > 0) {
			this.buildCooldown--;
		}
		if (this.digCooldown > 0) {
			this.digCooldown--;
		}

		// Ya no existe una fase de aproximacion agachada. Desde que aparece,
		// el Stalker permanece completamente erguido.
		this.stalker.setPose(net.minecraft.entity.EntityPose.STANDING);
		this.stalker.markReachedPlayer();

		// Mirar al jugador nunca vuelve a congelar al Stalker.
		boolean beingWatched =
				canSee
						&& distance <= STARE_MAX_DISTANCE
						&& isPlayerLookingAtStalker(player);

		if (beingWatched
					&& !this.wasBeingWatchedLastTick
					&& this.stareSoundCooldown <= 0) {
			StalkerSoundManager.playStare(this.stalker);
			this.stareSoundCooldown = STARE_SOUND_COOLDOWN_TICKS;
		}
		this.wasBeingWatchedLastTick = beingWatched;

		// Fuera de la huida, el Stalker SIEMPRE persigue al jugador.
		// Ya no existe una fase de caminar lento cerca del jugador.
		this.state = this.fleeTicksRemaining > 0
				? StalkerState.FLEEING
				: StalkerState.CHASING;

		switch (this.state) {
			case STALKING -> tickStalking(player);
			case CHASING -> tickChasing(world, player, distance);
			case FLEEING -> tickFleeing(player);
			case PATROLLING -> tickChasing(world, player, distance);
		}

		// Construccion de apoyo para seguir al jugador si este sube mucho.
		if (this.fleeTicksRemaining <= 0) {
			tryBuildVerticalPath(world, player);
			tryDigDownToPlayer(world, player);
		}

		// Sonidos de ambiente solo cuando esta razonablemente cerca del jugador.
		if (distance <= 32.0D && this.fleeTicksRemaining <= 0) {
			this.ambientSoundCooldown--;
			if (this.ambientSoundCooldown <= 0) {
				StalkerSoundManager.playAmbient(this.stalker, distance);
				this.ambientSoundCooldown = StalkerSoundManager.nextAmbientCooldown(this.stalker);
			}
		}
	}

	/**
	 * Primer golpe recibido por el Stalker: huye y reproduce exclusivamente
	 * stalker_despair_1. Cuando el Stalker golpea al jugador, tambien se aleja,
	 * pero no reproduce despair_1.
	 */
	public void notifyHit(boolean firstHitEver) {
		int min = firstHitEver
				? FIRST_HIT_FLEE_TICKS_MIN
				: POST_ATTACK_FLEE_TICKS_MIN;

		int max = firstHitEver
				? FIRST_HIT_FLEE_TICKS_MAX
				: POST_ATTACK_FLEE_TICKS_MAX;

		this.fleeTicksRemaining =
				min + this.stalker.getRandom().nextInt(max - min + 1);
		this.state = StalkerState.FLEEING;

		if (firstHitEver) {
			StalkerSoundManager.playDespair1(this.stalker);
		}
	}

	private void tickStalking(PlayerEntity player) {
		// Compatibilidad con el estado antiguo: nunca usar velocidad de acecho.
		this.stalker.getLookControl().lookAt(player, 30.0F, 30.0F);
		this.stalker.getNavigation().startMovingTo(player, SPEED_CHASING);
	}

	private void tickChasing(ServerWorld world, PlayerEntity player, double distance) {
		this.stalker.getLookControl().lookAt(player, 30.0F, 30.0F);

		double speed = player.isSprinting()
				? SPEED_CHASING_SPRINT
				: SPEED_CHASING;

		// Se actualiza constantemente aunque el jugador no este visible.
		this.stalker.getNavigation().startMovingTo(player, speed);

		if (this.stalker.hasBeenHit()
				&& distance <= ATTACK_RANGE
				&& this.attackCooldown <= 0) {
			this.attackCooldown = ATTACK_COOLDOWN_TICKS;

			boolean hit = this.stalker.tryAttack(world, player);
			if (hit) {
				this.notifyHit(false);
			}
		}
	}

	private void tickFleeing(PlayerEntity player) {
		this.fleeTicksRemaining--;

		Vec3d away = computeFleePoint(player);
		this.stalker.getNavigation().startMovingTo(
				away.x,
				away.y,
				away.z,
				SPEED_FLEEING
		);
		this.stalker.getLookControl().lookAt(away.x, away.y, away.z);

		if (this.fleeTicksRemaining <= 0) {
			this.state = StalkerState.CHASING;
		}
	}

	/**
	 * Si el jugador esta claramente por encima, construye una escalera de
	 * tablones hacia el jugador. Nunca coloca bloques si ambos estan en la
	 * misma altura.
	 */
	private void tryBuildVerticalPath(ServerWorld world, PlayerEntity player) {
		int playerY = player.getBlockPos().getY();
		int stalkerY = this.stalker.getBlockPos().getY();
		int verticalDifference = playerY - stalkerY;

		// Si ya estamos en la misma altura (o casi), no construimos nada.
		if (Math.abs(verticalDifference) <= 1) {
			return;
		}

		// Primero intentamos encontrar CUALQUIER camino natural hacia la zona
		// donde esta el jugador. Esto permite usar escaleras, escaleras de mano,
		// rampas, huecos, puentes y entradas de casas flotantes.
		Path directPath = this.stalker.getNavigation().findPathTo(player, 64);
		if (directPath != null && directPath.reachesTarget()) {
			return;
		}

		if (this.buildCooldown > 0) {
			return;
		}

		// Cuando el jugador esta arriba, buscamos alrededor suyo una posicion
		// caminable a SU MISMA ALTURA. Si encontramos una ruta hasta cualquiera
		// de ellas, el Stalker la usa en vez de construir.
		if (verticalDifference > 1) {
			BlockPos routeTarget = findReachablePositionNearPlayer(world, player);
			if (routeTarget != null) {
				this.stalker.getNavigation().startMovingTo(
						routeTarget.getX() + 0.5D,
						routeTarget.getY(),
						routeTarget.getZ() + 0.5D,
						SPEED_CHASING
				);
				return;
			}

			// No existe ninguna ruta hasta la altura del jugador: ahora sí puede
			// construir. Lo hace desde su posicion actual, un escalon por vez,
			// hasta llegar a la misma altura.
			buildOneStairStep(world, player);
		}
	}

	/**
	 * Revisa las posiciones alrededor del jugador a su misma altura.
	 * Se prueban primero las mas cercanas para encontrar una entrada natural
	 * como una escalera exterior de una casa flotante.
	 */
	private BlockPos findReachablePositionNearPlayer(ServerWorld world, PlayerEntity player) {
		BlockPos playerPos = player.getBlockPos();
		BlockPos best = null;
		double bestDistance = Double.MAX_VALUE;

		for (int radius = 1; radius <= 6; radius++) {
			for (int dx = -radius; dx <= radius; dx++) {
				for (int dz = -radius; dz <= radius; dz++) {
					if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) {
						continue;
					}

					BlockPos candidate = playerPos.add(dx, 0, dz);
					if (!isWalkablePosition(world, candidate)) {
						continue;
					}

					Path path = this.stalker.getNavigation().findPathTo(candidate, 64);
					if (path != null && path.reachesTarget()) {
						double distance = candidate.getSquaredDistance(this.stalker.getBlockPos());
						if (distance < bestDistance) {
							bestDistance = distance;
							best = candidate.toImmutable();
						}
					}
				}
			}
			if (best != null) {
				return best;
			}
		}

		return null;
	}

	private boolean isWalkablePosition(ServerWorld world, BlockPos pos) {
		BlockState feet = world.getBlockState(pos);
		BlockState head = world.getBlockState(pos.up());
		BlockState floor = world.getBlockState(pos.down());

		return feet.isAir()
				&& head.isAir()
				&& floor.isSolidBlock(world, pos.down())
				&& floor.getFluidState().isEmpty();
	}

	/**
	 * Construye un escalon que avanza hacia el jugador. No reemplaza bloques
	 * existentes: si encuentra una estructura, la respeta y deja que la
	 * navegacion intente utilizarla en el siguiente ciclo.
	 */
	private void buildOneStairStep(ServerWorld world, PlayerEntity player) {
		BlockPos current = this.stalker.getBlockPos();
		if (current.getY() >= world.getTopYInclusive() - 2) {
			return;
		}

		int targetX = player.getBlockPos().getX();
		int targetZ = player.getBlockPos().getZ();
		int stepX = Integer.compare(targetX, current.getX());
		int stepZ = Integer.compare(targetZ, current.getZ());

		// Si ya estamos exactamente debajo del jugador, elegimos un lateral
		// para formar una escalera por donde el Stalker pueda subir.
		if (stepX == 0 && stepZ == 0) {
			stepX = 1;
		}

		BlockPos stepPos = current.add(stepX, 1, stepZ);
		BlockPos supportPos = stepPos.down();

		// No construimos dentro del espacio del jugador ni fuera del mundo.
		if (stepPos.getY() > player.getBlockPos().getY()
				|| stepPos.getY() >= world.getTopYInclusive()) {
			return;
		}

		BlockState stepState = world.getBlockState(stepPos);
		if (!stepState.isAir()) {
			// Ya existe un bloque en el siguiente nivel; intentamos subir hacia él.
			this.stalker.getNavigation().startMovingTo(
					stepPos.getX() + 0.5D,
					stepPos.getY(),
					stepPos.getZ() + 0.5D,
					SPEED_CHASING
			);
			return;
		}

		// El escalon debe poder sostenerse. Si falta el soporte, colocamos primero
		// el bloque inferior y luego el escalon.
		if (world.getBlockState(supportPos).isAir()) {
			if (!world.setBlockState(
					supportPos,
					Blocks.OAK_PLANKS.getDefaultState(),
					Block.NOTIFY_ALL)) {
				return;
			}
		}

		if (world.setBlockState(
				stepPos,
				Blocks.OAK_PLANKS.getDefaultState(),
				Block.NOTIFY_ALL)) {
			this.buildCooldown = BUILD_COOLDOWN_TICKS;
			this.stalker.getNavigation().startMovingTo(
					stepPos.getX() + 0.5D,
					stepPos.getY(),
					stepPos.getZ() + 0.5D,
					SPEED_CHASING
			);
		}
	}

	/**
	 * Si el jugador esta por debajo y no existe una ruta para bajar, el Stalker
	 * puede excavar verticalmente con las mismas limitaciones de un pico de
	 * hierro. Solo rompe el bloque inmediatamente debajo de el, un bloque cada
	 * cierto tiempo, hasta volver a la capa del jugador.
	 */
	private void tryDigDownToPlayer(ServerWorld world, PlayerEntity player) {
		double dx = player.getX() - this.stalker.getX();
		double dz = player.getZ() - this.stalker.getZ();
		double horizontalDistanceSq = dx * dx + dz * dz;
		if (horizontalDistanceSq > 2.25D) {
			this.diggingPos = null;
			return;
		}

		int stalkerFeetY = this.stalker.getBlockPos().getY();
		int playerFeetY = player.getBlockPos().getY();
		if (stalkerFeetY - playerFeetY < 2) {
			this.diggingPos = null;
			return;
		}
		if (this.digCooldown > 0) {
			return;
		}

		// Si hay una ruta valida para bajar, la usa y no rompe bloques.
		Path pathToPlayer = this.stalker.getNavigation().findPathTo(player, 32);
		if (pathToPlayer != null && pathToPlayer.reachesTarget()) {
			this.diggingPos = null;
			return;
		}

		BlockPos blockToBreak = this.stalker.getBlockPos().down();
		BlockState state = world.getBlockState(blockToBreak);
		if (state.isAir() || !state.isSolidBlock(world, blockToBreak)) {
			this.diggingPos = null;
			return;
		}

		// El comportamiento esta limitado a lo que puede minar un pico de hierro.
		ItemStack ironPickaxe = new ItemStack(Items.IRON_PICKAXE);
		if (!ironPickaxe.isSuitableFor(state)) {
			this.diggingPos = null;
			return;
		}

		if (!blockToBreak.equals(this.diggingPos)) {
			this.diggingPos = blockToBreak.toImmutable();
			this.digCooldown = 20;
			this.stalker.getLookControl().lookAt(
					blockToBreak.getX() + 0.5D,
					blockToBreak.getY() + 0.5D,
					blockToBreak.getZ() + 0.5D
			);
			return;
		}

		this.stalker.swingHand(net.minecraft.util.Hand.MAIN_HAND);
		this.stalker.getLookControl().lookAt(
				blockToBreak.getX() + 0.5D,
				blockToBreak.getY() + 0.5D,
				blockToBreak.getZ() + 0.5D
		);

		if (world.breakBlock(blockToBreak, false, this.stalker)) {
			this.diggingPos = null;
			this.digCooldown = 10;
		}
	}

	private Vec3d computeFleePoint(PlayerEntity player) {
		Vec3d fromPlayerToStalker =
				this.stalker.getEntityPos().subtract(player.getEntityPos());

		if (fromPlayerToStalker.lengthSquared() < 0.01) {
			double angle = this.stalker.getRandom().nextDouble() * Math.PI * 2.0;
			fromPlayerToStalker = new Vec3d(Math.cos(angle), 0, Math.sin(angle));
		}

		Vec3d direction = fromPlayerToStalker.normalize();
		double distance = FLEE_DISTANCE_MIN
				+ this.stalker.getRandom().nextDouble()
				* (FLEE_DISTANCE_MAX - FLEE_DISTANCE_MIN);

		return player.getEntityPos().add(direction.multiply(distance));
	}

	private boolean isPlayerLookingAtStalker(PlayerEntity player) {
		Vec3d lookDirection = player.getRotationVec(1.0F);
		Vec3d toStalker = this.stalker.getEyePos()
				.subtract(player.getEyePos())
				.normalize();

		double dot = lookDirection.normalize().dotProduct(toStalker);
		double angle = Math.acos(Math.clamp(dot, -1.0, 1.0));
		return angle <= STARE_ANGLE_RADIANS;
	}
}
