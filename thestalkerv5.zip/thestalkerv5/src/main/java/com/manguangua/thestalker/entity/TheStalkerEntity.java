package com.manguangua.thestalker.entity;

import com.manguangua.thestalker.entity.ai.StalkerBehaviorGoal;
import com.manguangua.thestalker.entity.ai.StalkerDoorBreakingGoal;
import com.manguangua.thestalker.registry.ModEntities;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.UUID;

public class TheStalkerEntity extends HostileEntity {

    private static final String KEY_HAS_BEEN_HIT = "HasBeenHit";
    private static final String KEY_TARGET_UUID = "TargetPlayerUuid";
    private static final String KEY_LAST_KNOWN_X = "LastKnownX";
    private static final String KEY_LAST_KNOWN_Y = "LastKnownY";
    private static final String KEY_LAST_KNOWN_Z = "LastKnownZ";
    private static final String KEY_HAS_LAST_KNOWN = "HasLastKnownPos";

    private boolean hasBeenHit = false;
    private UUID targetPlayerUuid;
    private Vec3d lastKnownPlayerPos;
    private boolean hasLastKnownPos = false;
    private StalkerBehaviorGoal behaviorGoal;

    public TheStalkerEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createStalkerAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 20.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.24)
                .add(EntityAttributes.ATTACK_DAMAGE, 6.0)
                .add(EntityAttributes.ATTACK_KNOCKBACK, 0.3)
                .add(EntityAttributes.FOLLOW_RANGE, 128.0)
                .add(EntityAttributes.STEP_HEIGHT, 1.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new StalkerDoorBreakingGoal(this));
        this.behaviorGoal = new StalkerBehaviorGoal(this);
        this.goalSelector.add(2, this.behaviorGoal);
        this.goalSelector.add(8, new LookAroundGoal(this));
    }

    public PlayerEntity resolveTargetPlayer() {
        if (!(this.getEntityWorld() instanceof ServerWorld serverWorld)) {
            return null;
        }
        if (this.targetPlayerUuid != null) {
            PlayerEntity saved = serverWorld.getPlayerByUuid(this.targetPlayerUuid);
            if (saved != null && saved.isAlive() && !saved.isSpectator()) {
                return saved;
            }
        }
        return serverWorld.getClosestPlayer(this, -1.0D);
    }

    public void setTargetPlayer(UUID uuid) { this.targetPlayerUuid = uuid; }
    public UUID getTargetPlayerUuid() { return this.targetPlayerUuid; }
    public boolean hasBeenHit() { return this.hasBeenHit; }
    public void markAsHit() { this.hasBeenHit = true; }
    public void updateLastKnownPlayerPos(Vec3d pos) { this.lastKnownPlayerPos = pos; this.hasLastKnownPos = true; }
    public Vec3d getLastKnownPlayerPos() { return this.lastKnownPlayerPos; }
    public boolean hasLastKnownPlayerPos() { return this.hasLastKnownPos; }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    // ✅ CORREGIDO: writeNbt -> writeCustomDataToNbt (Yarn 1.21.11)
    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean(KEY_HAS_BEEN_HIT, this.hasBeenHit);
        if (this.targetPlayerUuid != null) {
            nbt.putString(KEY_TARGET_UUID, this.targetPlayerUuid.toString());
        }
        if (this.hasLastKnownPos && this.lastKnownPlayerPos != null) {
            nbt.putBoolean(KEY_HAS_LAST_KNOWN, true);
            nbt.putDouble(KEY_LAST_KNOWN_X, this.lastKnownPlayerPos.x);
            nbt.putDouble(KEY_LAST_KNOWN_Y, this.lastKnownPlayerPos.y);
            nbt.putDouble(KEY_LAST_KNOWN_Z, this.lastKnownPlayerPos.z);
        }
    }

    // ✅ CORREGIDO: readNbt -> readCustomDataFromNbt (Yarn 1.21.11)
    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        // getBoolean() ahora devuelve Optional<Boolean>
        this.hasBeenHit = nbt.getBoolean(KEY_HAS_BEEN_HIT).orElse(false);
        if (nbt.contains(KEY_TARGET_UUID)) {
            // getString() ahora devuelve Optional<String>
            nbt.getString(KEY_TARGET_UUID).ifPresent(uuid -> this.targetPlayerUuid = UUID.fromString(uuid));
        }
        if (nbt.getBoolean(KEY_HAS_LAST_KNOWN).orElse(false)) {
            // getDouble() ahora devuelve Optional<Double>
            double x = nbt.getDouble(KEY_LAST_KNOWN_X).orElse(0.0);
            double y = nbt.getDouble(KEY_LAST_KNOWN_Y).orElse(0.0);
            double z = nbt.getDouble(KEY_LAST_KNOWN_Z).orElse(0.0);
            this.lastKnownPlayerPos = new Vec3d(x, y, z);
            this.hasLastKnownPos = true;
        }
    }

    @Override
    public boolean damage(ServerWorld world, DamageSource source, float amount) {
        boolean result = super.damage(world, source, amount);
        if (result && !this.hasBeenHit && source.getAttacker() instanceof PlayerEntity) {
            this.markAsHit();
            if (this.behaviorGoal != null) {
                this.behaviorGoal.notifyHit(true);
            }
        }
        return result;
    }

    @Override
    public boolean tryAttack(ServerWorld world, net.minecraft.entity.Entity target) {
        if (!this.hasBeenHit) return false;
        return super.tryAttack(world, target);
    }

    @Override
    public void onDeath(DamageSource damageSource) {
        super.onDeath(damageSource);
        if (this.getEntityWorld() instanceof ServerWorld serverWorld) {
            com.manguangua.thestalker.spawn.StalkerSpawnHandler.onStalkerDied(serverWorld, this.getUuid());
        }
    }

    public static TheStalkerEntity create(ServerWorld world) {
        return ModEntities.THE_STALKER.create(world, SpawnReason.MOB_SUMMONED);
    }
}