package com.manguangua.thestalker.entity.ai;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.sound.StalkerSoundManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

/**
 * Hace que el Stalker revise los cofres de una casa uno por uno.
 *
 * No roba ni modifica los objetos: inspecciona cada slot secuencialmente,
 * mantiene el cofre abierto durante la revision y despues pasa al siguiente.
 * Solo funciona cuando el Stalker esta dentro de una estructura/casa
 * (sin cielo abierto) y cerca de su jugador objetivo.
 */
public class StalkerChestReviewGoal extends Goal {

	private static final int CHEST_SEARCH_RADIUS = 12;
	private static final double PLAYER_MAX_DISTANCE = 20.0D;
	private static final double CHEST_REACH_DISTANCE_SQ = 3.0D * 3.0D;
	private static final int REVIEW_TICKS = 160;
	private static final int SLOT_REVIEW_INTERVAL = 3;
	private static final double MOVE_SPEED = 0.75D;

	private final TheStalkerEntity stalker;
	private final Set<BlockPos> reviewedChests = new HashSet<>();

	private BlockPos targetChestPos;
	private ChestBlockEntity targetChestEntity;
	private Inventory targetInventory;
	private int reviewTicks;
	private int slotTimer;
	private int reviewSlot;
	private boolean reviewing;

	public StalkerChestReviewGoal(TheStalkerEntity stalker) {
		this.stalker = stalker;
		this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
	}

	@Override
	public boolean canStart() {
		if (!(this.stalker.getEntityWorld() instanceof ServerWorld world)) {
			return false;
		}

		PlayerEntity player = this.stalker.resolveTargetPlayer();
		if (player == null || !player.isAlive()) {
			return false;
		}

		if (this.stalker.distanceTo(player) > PLAYER_MAX_DISTANCE) {
			return false;
		}

		if (!isInsideStructure(world, this.stalker.getBlockPos())) {
			return false;
		}

		BlockPos chest = findNearestUnreviewedChest(world);
		if (chest == null) {
			return false;
		}

		this.targetChestPos = chest;
		return true;
	}

	@Override
	public boolean shouldContinue() {
		if (this.targetChestPos == null) {
			return false;
		}

		if (this.reviewing) {
			return this.reviewTicks > 0;
		}

		return this.stalker.getEntityWorld().getBlockState(this.targetChestPos).getBlock()
				instanceof ChestBlock;
	}

	@Override
	public void start() {
		this.reviewing = false;
		this.reviewTicks = 0;
		this.slotTimer = 0;
		this.reviewSlot = 0;
		this.targetChestEntity = null;
		this.targetInventory = null;
	}

	@Override
	public void stop() {
		closeChest();
		this.stalker.getNavigation().stop();
		this.targetChestPos = null;
		this.targetChestEntity = null;
		this.targetInventory = null;
		this.reviewing = false;
	}

	@Override
	public void tick() {
		if (!(this.stalker.getEntityWorld() instanceof ServerWorld world)
				|| this.targetChestPos == null) {
			return;
		}

		BlockState state = world.getBlockState(this.targetChestPos);
		if (!(state.getBlock() instanceof ChestBlock chestBlock)) {
			this.targetChestPos = null;
			return;
		}

		this.stalker.getLookControl().lookAt(
				this.targetChestPos.getX() + 0.5D,
				this.targetChestPos.getY() + 0.5D,
				this.targetChestPos.getZ() + 0.5D
		);

		if (!this.reviewing) {
			double distanceSq = this.stalker.getEntityPos().squaredDistanceTo(
					this.targetChestPos.getX() + 0.5D,
					this.targetChestPos.getY() + 0.5D,
					this.targetChestPos.getZ() + 0.5D
			);

			if (distanceSq > CHEST_REACH_DISTANCE_SQ) {
				this.stalker.getNavigation().startMovingTo(
						this.targetChestPos.getX() + 0.5D,
						this.targetChestPos.getY(),
						this.targetChestPos.getZ() + 0.5D,
						MOVE_SPEED
				);
				return;
			}

			// Para que ambient_3 sea el sonido de la revision, esperamos a que
			// termine cualquier otro sonido del Stalker antes de abrir el cofre.
			if (StalkerSoundManager.isBusy(this.stalker)) {
				return;
			}

			ChestBlockEntity chestEntity = null;
			if (world.getBlockEntity(this.targetChestPos) instanceof ChestBlockEntity entity) {
				chestEntity = entity;
			}

			Inventory inventory = ChestBlock.getInventory(
					chestBlock,
					state,
					world,
					this.targetChestPos,
					false
			);

			if (chestEntity == null || inventory == null) {
				this.reviewedChests.add(this.targetChestPos.toImmutable());
				this.targetChestPos = null;
				return;
			}

			this.targetChestEntity = chestEntity;
			this.targetInventory = inventory;
			this.reviewSlot = 0;
			this.slotTimer = 0;
			this.reviewTicks = REVIEW_TICKS;
			this.reviewing = true;
			this.stalker.getNavigation().stop();

			// Abre visualmente el cofre y reproduce stalker_ambient_3.
			this.targetChestEntity.onOpen(this.stalker);
			StalkerSoundManager.playChestReview(this.stalker);
			return;
		}

		this.stalker.getNavigation().stop();
		this.reviewTicks--;
		this.slotTimer--;

		// Revisa los slots uno por uno sin retirar ni alterar los objetos.
		if (this.slotTimer <= 0) {
			this.slotTimer = SLOT_REVIEW_INTERVAL;
			if (this.targetInventory != null
					&& this.reviewSlot < this.targetInventory.size()) {
				this.targetInventory.getStack(this.reviewSlot);
				this.reviewSlot++;
			}
		}

		if (this.reviewTicks <= 0) {
			finishReview();
		}
	}

	private void finishReview() {
		closeChest();
		if (this.targetChestPos != null) {
			markChestAndPartnerReviewed(this.targetChestPos);
		}
		this.targetChestEntity = null;
		this.targetInventory = null;
		this.targetChestPos = null;
		this.reviewing = false;
	}

	private void closeChest() {
		if (this.targetChestEntity != null) {
			this.targetChestEntity.onClose(this.stalker);
		}
	}

	private BlockPos findNearestUnreviewedChest(ServerWorld world) {
		BlockPos origin = this.stalker.getBlockPos();
		BlockPos best = null;
		double bestDistance = Double.MAX_VALUE;

		BlockPos start = origin.add(-CHEST_SEARCH_RADIUS, -2, -CHEST_SEARCH_RADIUS);
		BlockPos end = origin.add(CHEST_SEARCH_RADIUS, 3, CHEST_SEARCH_RADIUS);

		for (BlockPos pos : BlockPos.iterate(start, end)) {
			BlockPos immutable = pos.toImmutable();
			if (this.reviewedChests.contains(immutable)) {
				continue;
			}

			BlockState state = world.getBlockState(pos);
			if (!(state.getBlock() instanceof ChestBlock chestBlock)) {
				continue;
			}

			if (ChestBlock.getInventory(chestBlock, state, world, pos, false) == null) {
				continue;
			}

			double d = this.stalker.getEntityPos().squaredDistanceTo(
					pos.getX() + 0.5D,
					pos.getY() + 0.5D,
					pos.getZ() + 0.5D
			);
			if (d < bestDistance) {
				bestDistance = d;
				best = immutable;
			}
		}

		return best;
	}

	private void markChestAndPartnerReviewed(BlockPos pos) {
		this.reviewedChests.add(pos.toImmutable());

		ServerWorld world = (ServerWorld) this.stalker.getEntityWorld();
		BlockState state = world.getBlockState(pos);
		if (!(state.getBlock() instanceof ChestBlock)) {
			return;
		}

		if (!state.contains(Properties.CHEST_TYPE)
				|| state.get(Properties.CHEST_TYPE) == ChestType.SINGLE) {
			return;
		}

		Direction facing = ChestBlock.getFacing(state);
		for (Direction direction : Direction.Type.HORIZONTAL) {
			BlockPos neighborPos = pos.offset(direction);
			BlockState neighbor = world.getBlockState(neighborPos);
			if (!(neighbor.getBlock() instanceof ChestBlock)) {
				continue;
			}
			if (neighbor.contains(Properties.CHEST_TYPE)
					&& neighbor.get(Properties.CHEST_TYPE) != ChestType.SINGLE
					&& ChestBlock.getFacing(neighbor) == facing) {
				this.reviewedChests.add(neighborPos.toImmutable());
			}
		}
	}

	private boolean isInsideStructure(ServerWorld world, BlockPos pos) {
		// Una casa puede tener un techo alto; buscamos un techo solido hasta
		// seis bloques por encima. El cielo abierto no cuenta como interior.
		for (int y = 1; y <= 6; y++) {
			BlockState above = world.getBlockState(pos.up(y));
			if (!above.isAir() && above.isSolidBlock(world, pos.up(y))) {
				return true;
			}
		}
		return false;
	}
}
