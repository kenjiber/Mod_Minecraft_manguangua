package com.manguangua.thestalker.entity.ai;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.sound.StalkerSoundManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

/**
 * Persecucion persistente del jugador objetivo.
 *
 * El Stalker ya no pierde al jugador ni entra en patrulla: mientras el jugador
 * siga conectado y vivo, continua intentando llegar hasta el, incluso si
 * deja de verlo. Tambien puede construir una torre de tablones cuando el
 * jugador esta claramente por encima.
 */
public class StalkerBehaviorGoal extends Goal {

	private static final double APPROACH_CLOSE_DISTANCE = 8.0;
	private static final double CHASE_DISTANCE_THRESHOLD = 18.0;

	private static final double FLEE_DISTANCE_MIN = 20.0;
	private static final double FLEE_DISTANCE_MAX = 30.0;
	private static final int FIRST_HIT_FLEE_TICKS_MIN = 200;
	private static final int FIRST_HIT_FLEE_TICKS_MAX = 300;
	private static final int POST_ATTACK_FLEE_TICKS_MIN = 60;
	private static final int POST_ATTACK_FLEE_TICKS_MAX = 100;

	private static final double STARE_ANGLE_RADIANS = Math.toRadians(20.0);
	private static final double STARE_MAX_DISTANCE = 40.0;
	private static final int STARE_SOUND_COOLDOWN_TICKS = 100;

	private static final double ATTACK_RANGE = 2.3;
	private static final int ATTACK_COOLDOWN_TICKS = 20;

	private static final double SPEED_STALKING = 0.55;
	private static final double SPEED_CHASING = 1.15;
	private static final double SPEED_CHASING_SPRINT = 1.35;
	private static final double SPEED_FLEEING = 1.25;

	/** Cada cuantos ticks como minimo intenta construir hacia arriba. */
	private static final int BUILD_COOLDOWN_TICKS = 10;
	private static final double BUILD_MIN_VERTICAL_ADVANTAGE = 1.5;

	private final TheStalkerEntity stalker;

	private StalkerState state = StalkerState.STALKING;
	private int fleeTicksRemaining = 0;
	private int stareSoundCooldown = 0;
	private int attackCooldown = 0;
	private int buildCooldown = 0;
	private int digCooldown = 0;
	private BlockPos diggingPos;
	private int ambientSoundCooldown;
	private boolean wasBeingWatchedLastTick = false;

	public StalkerBehaviorGoal(TheStalkerEntity stalker) {
		this.stalker = stalker;
		this.ambientSoundCooldown = StalkerSoundManager.nextAmbientCooldown(stalker);
		this.setControls(EnumSet.of(
				Goal.Control.MOVE,
				Goal.Control.LOOK,
				Goal.Control.JUMP
		));
	}

	@Override
	public boolean canStart() {
		return this.stalker.getEntityWorld() instanceof ServerWorld
				&& this.stalker.resolveTargetPlayer() != null;
	}

	@Override
	public boolean shouldContinue() {
		return this.canStart();
	}

	@Override
	public void start() {
		this.state = StalkerState.STALKING;
		// El Stalker siempre se mantiene erguido.
		this.stalker.setPose(net.minecraft.entity.EntityPose.STANDING);
	}

	@Override
	public void stop() {
		this.stalker.getNavigation().stop();
	}

	@Override
	public void tick() {
		if (!(this.stalker.getEntityWorld() instanceof ServerWorld world)) {
			return;
		}

		PlayerEntity player = this.stalker.resolveTargetPlayer();
		if (player == null) {
			return;
		}

		double distance = this.stalker.distanceTo(player);
		boolean canSee = this.stalker.canSee(player);

		if (this.attackCooldown > 0) {
			this.attackCooldown--;
		}
		if (this.stareSoundCooldown > 0) {
			this.stareSoundCooldown--;
		}
		if (this.buildCooldown > 0) {
			this.buildCooldown--;
		}
		if (this.digCooldown > 0) {
			this.digCooldown--;
		}

		// Ya no existe una fase de aproximacion agachada. Desde que aparece,
		// el Stalker permanece completamente erguido.
		this.stalker.setPose(net.minecraft.entity.EntityPose.STANDING);
		this.stalker.markReachedPlayer();

		// Mirar al jugador nunca vuelve a congelar al Stalker.
		boolean beingWatched =
				canSee
						&& distance <= STARE_MAX_DISTANCE
						&& isPlayerLookingAtStalker(player);

		if (beingWatched
					&& !this.wasBeingWatchedLastTick
					&& this.stareSoundCooldown <= 0) {
			StalkerSoundManager.playStare(this.stalker);
			this.stareSoundCooldown = STARE_SOUND_COOLDOWN_TICKS;
		}
		this.wasBeingWatchedLastTick = beingWatched;

		if (this.fleeTicksRemaining > 0) {
			this.state = StalkerState.FLEEING;
		} else if (player.isSprinting() || distance > CHASE_DISTANCE_THRESHOLD) {
			this.state = StalkerState.CHASING;
		} else {
			this.state = StalkerState.STALKING;
		}

		switch (this.state) {
			case STALKING -> tickStalking(player);
			case CHASING -> tickChasing(world, player, distance);
			case FLEEING -> tickFleeing(player);
			case PATROLLING -> tickChasing(world, player, distance);
		}

		// Construccion de apoyo para seguir al jugador si este sube mucho.
		if (this.fleeTicksRemaining <= 0) {
			tryBuildVerticalPath(world, player);
			tryDigDownToPlayer(world, player);
		}

		// Sonidos de ambiente solo cuando esta razonablemente cerca del jugador.
		if (distance <= 32.0D && this.fleeTicksRemaining <= 0) {
			this.ambientSoundCooldown--;
			if (this.ambientSoundCooldown <= 0) {
				StalkerSoundManager.playAmbient(this.stalker, distance);
				this.ambientSoundCooldown = StalkerSoundManager.nextAmbientCooldown(this.stalker);
			}
		}
	}

	/**
	 * Primer golpe recibido por el Stalker: huye y reproduce exclusivamente
	 * stalker_despair_1. Cuando el Stalker golpea al jugador, tambien se aleja,
	 * pero no reproduce despair_1.
	 */
	public void notifyHit(boolean firstHitEver) {
		int min = firstHitEver
				? FIRST_HIT_FLEE_TICKS_MIN
				: POST_ATTACK_FLEE_TICKS_MIN;

		int max = firstHitEver
				? FIRST_HIT_FLEE_TICKS_MAX
				: POST_ATTACK_FLEE_TICKS_MAX;

		this.fleeTicksRemaining =
				min + this.stalker.getRandom().nextInt(max - min + 1);
		this.state = StalkerState.FLEEING;

		if (firstHitEver) {
			StalkerSoundManager.playDespair1(this.stalker);
		}
	}

	private void tickStalking(PlayerEntity player) {
		this.stalker.getLookControl().lookAt(player, 30.0F, 30.0F);
		this.stalker.getNavigation().startMovingTo(player, SPEED_STALKING);
	}

	private void tickChasing(ServerWorld world, PlayerEntity player, double distance) {
		this.stalker.getLookControl().lookAt(player, 30.0F, 30.0F);

		double speed = player.isSprinting()
				? SPEED_CHASING_SPRINT
				: SPEED_CHASING;

		// Se actualiza constantemente aunque el jugador no este visible.
		this.stalker.getNavigation().startMovingTo(player, speed);

		if (this.stalker.hasBeenHit()
				&& distance <= ATTACK_RANGE
				&& this.attackCooldown <= 0) {
			this.attackCooldown = ATTACK_COOLDOWN_TICKS;

			boolean hit = this.stalker.tryAttack(world, player);
			if (hit) {
				this.notifyHit(false);
			}
		}
	}

	private void tickFleeing(PlayerEntity player) {
		this.fleeTicksRemaining--;

		Vec3d away = computeFleePoint(player);
		this.stalker.getNavigation().startMovingTo(
				away.x,
				away.y,
				away.z,
				SPEED_FLEEING
		);
		this.stalker.getLookControl().lookAt(away.x, away.y, away.z);

		if (this.fleeTicksRemaining <= 0) {
			this.state = StalkerState.CHASING;
		}
	}

	/**
	 * Si el jugador esta claramente por encima, construye una escalera de
	 * tablones hacia el jugador. Nunca coloca bloques si ambos estan en la
	 * misma altura.
	 */
	private void tryBuildVerticalPath(ServerWorld world, PlayerEntity player) {
		// Solo construye cuando esta practicamente al lado del jugador.
		double dx = player.getX() - this.stalker.getX();
		double dz = player.getZ() - this.stalker.getZ();
		double horizontalDistanceSq = dx * dx + dz * dz;
		if (horizontalDistanceSq > 2.25D) {
			return;
		}

		// Esta rutina es EXCLUSIVAMENTE para subir. Si el jugador esta en la
		// misma capa o por debajo, nunca coloca bloques.
		int playerFeetY = player.getBlockPos().getY();
		int stalkerFeetY = this.stalker.getBlockPos().getY();
		int levelsAbove = playerFeetY - stalkerFeetY;
		if (levelsAbove < 2 || this.buildCooldown > 0) {
			return;
		}

		// Si existe una ruta de navegacion real, por ejemplo unas escaleras,
		// rampas o el interior de una casa de dos pisos, no construye nada.
		Path pathToPlayer = this.stalker.getNavigation().findPathTo(player, 32);
		if (pathToPlayer != null && pathToPlayer.reachesTarget()) {
			return;
		}

		BlockPos current = this.stalker.getBlockPos();
		if (current.getY() >= world.getTopYInclusive() - 2) {
			return;
		}

		// El Stalker construye una escalera paralela al ascenso del jugador.
		// Cada nivel queda a un bloque horizontal del nivel anterior, de modo
		// que no se queda limitado a colocar un unico bloque.
		int stepX = Integer.compare((int) Math.floor(player.getX()), current.getX());
		int stepZ = Integer.compare((int) Math.floor(player.getZ()), current.getZ());
		if (stepX == 0 && stepZ == 0) {
			// Si estan exactamente alineados, elegimos el lateral mas corto para
			// poder formar una escalera sin colocar un bloque dentro del Stalker.
			if (Math.abs(dx) <= Math.abs(dz)) {
				stepX = 1;
			} else {
				stepZ = 1;
			}
		}

		BlockPos stepPos = current.add(stepX, 0, stepZ);
		BlockPos supportPos = stepPos.down();
		if (stepPos.getY() >= playerFeetY + 1) {
			return;
		}
		if (!world.getBlockState(stepPos).isAir()) {
			// Si ya hay un bloque de la escalera, simplemente intentamos subir
			// hacia el siguiente nivel; no reemplazamos bloques del jugador.
			this.stalker.getNavigation().startMovingTo(
					stepPos.getX() + 0.5D,
					stepPos.getY() + 1.0D,
					stepPos.getZ() + 0.5D,
					SPEED_CHASING
			);
			return;
		}

		if (supportPos.getY() < world.getBottomY()) {
			return;
		}

		// El bloque de apoyo se crea solo si hace falta. Asi cada escalon queda
		// sostenido y el Stalker puede ir avanzando nivel por nivel.
		if (world.getBlockState(supportPos).isAir()) {
			if (!world.setBlockState(
					supportPos,
					Blocks.OAK_PLANKS.getDefaultState(),
					Block.NOTIFY_ALL)) {
				return;
			}
		}

		if (world.setBlockState(
				stepPos,
				Blocks.OAK_PLANKS.getDefaultState(),
				Block.NOTIFY_ALL)) {
			this.buildCooldown = BUILD_COOLDOWN_TICKS;
			this.stalker.getNavigation().startMovingTo(
					stepPos.getX() + 0.5D,
					stepPos.getY() + 1.0D,
					stepPos.getZ() + 0.5D,
					SPEED_CHASING
			);
		}
	}

	/**
	 * Si el jugador esta por debajo y no existe una ruta para bajar, el Stalker
	 * puede excavar verticalmente con las mismas limitaciones de un pico de
	 * hierro. Solo rompe el bloque inmediatamente debajo de el, un bloque cada
	 * cierto tiempo, hasta volver a la capa del jugador.
	 */
	private void tryDigDownToPlayer(ServerWorld world, PlayerEntity player) {
		double dx = player.getX() - this.stalker.getX();
		double dz = player.getZ() - this.stalker.getZ();
		double horizontalDistanceSq = dx * dx + dz * dz;
		if (horizontalDistanceSq > 2.25D) {
			this.diggingPos = null;
			return;
		}

		int stalkerFeetY = this.stalker.getBlockPos().getY();
		int playerFeetY = player.getBlockPos().getY();
		if (stalkerFeetY - playerFeetY < 2) {
			this.diggingPos = null;
			return;
		}
		if (this.digCooldown > 0) {
			return;
		}

		// Si hay una ruta valida para bajar, la usa y no rompe bloques.
		Path pathToPlayer = this.stalker.getNavigation().findPathTo(player, 32);
		if (pathToPlayer != null && pathToPlayer.reachesTarget()) {
			this.diggingPos = null;
			return;
		}

		BlockPos blockToBreak = this.stalker.getBlockPos().down();
		BlockState state = world.getBlockState(blockToBreak);
		if (state.isAir() || !state.isSolidBlock(world, blockToBreak)) {
			this.diggingPos = null;
			return;
		}

		// El comportamiento esta limitado a lo que puede minar un pico de hierro.
		ItemStack ironPickaxe = new ItemStack(Items.IRON_PICKAXE);
		if (!ironPickaxe.isSuitableFor(state)) {
			this.diggingPos = null;
			return;
		}

		if (!blockToBreak.equals(this.diggingPos)) {
			this.diggingPos = blockToBreak.toImmutable();
			this.digCooldown = 20;
			this.stalker.getLookControl().lookAt(
					blockToBreak.getX() + 0.5D,
					blockToBreak.getY() + 0.5D,
					blockToBreak.getZ() + 0.5D
			);
			return;
		}

		this.stalker.swingHand(net.minecraft.util.Hand.MAIN_HAND);
		this.stalker.getLookControl().lookAt(
				blockToBreak.getX() + 0.5D,
				blockToBreak.getY() + 0.5D,
				blockToBreak.getZ() + 0.5D
		);

		if (world.breakBlock(blockToBreak, false, this.stalker)) {
			this.diggingPos = null;
			this.digCooldown = 10;
		}
	}

	private Vec3d computeFleePoint(PlayerEntity player) {
		Vec3d fromPlayerToStalker =
				this.stalker.getEntityPos().subtract(player.getEntityPos());

		if (fromPlayerToStalker.lengthSquared() < 0.01) {
			double angle = this.stalker.getRandom().nextDouble() * Math.PI * 2.0;
			fromPlayerToStalker = new Vec3d(Math.cos(angle), 0, Math.sin(angle));
		}

		Vec3d direction = fromPlayerToStalker.normalize();
		double distance = FLEE_DISTANCE_MIN
				+ this.stalker.getRandom().nextDouble()
				* (FLEE_DISTANCE_MAX - FLEE_DISTANCE_MIN);

		return player.getEntityPos().add(direction.multiply(distance));
	}

	private boolean isPlayerLookingAtStalker(PlayerEntity player) {
		Vec3d lookDirection = player.getRotationVec(1.0F);
		Vec3d toStalker = this.stalker.getEyePos()
				.subtract(player.getEyePos())
				.normalize();

		double dot = lookDirection.normalize().dotProduct(toStalker);
		double angle = Math.acos(Math.clamp(dot, -1.0, 1.0));
		return angle <= STARE_ANGLE_RADIANS;
	}
}
