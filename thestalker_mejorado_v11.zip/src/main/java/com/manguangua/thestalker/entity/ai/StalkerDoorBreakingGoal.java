package com.manguangua.thestalker.entity.ai;

import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.sound.StalkerSoundManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.EnumSet;

/**
 * Rompe una puerta/trampilla/valla SOLO cuando ese obstaculo esta realmente
 * entre el Stalker y su jugador objetivo.
 *
 * El Stalker puede seguir detectando al jugador aunque haya bloques entre
 * ambos porque la persecucion principal no depende de canSee(). Sin embargo,
 * este Goal no rompe bloques a ciegas: solo actua cuando el primer obstaculo
 * del rayo hacia el jugador es una puerta/trampilla/valla cerrada.
 */
public class StalkerDoorBreakingGoal extends Goal {

	private static final int HITS_REQUIRED_DOOR = 7;
	private static final int HITS_REQUIRED_FENCE = 14;
	private static final int HIT_INTERVAL_TICKS = 20;
	private static final boolean DROP_BLOCK_ON_BREAK = false;

	private final TheStalkerEntity stalker;

	private BlockPos targetPos;
	private int hitsRequired;
	private int hitsLanded;
	private int hitCooldown;

	public StalkerDoorBreakingGoal(TheStalkerEntity stalker) {
		this.stalker = stalker;
		this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
	}

	@Override
	public boolean canStart() {
		if (!(this.stalker.getEntityWorld() instanceof ServerWorld world)) {
			return false;
		}

		PlayerEntity player = this.stalker.resolveTargetPlayer();
		if (player == null || !player.isAlive()) {
			return false;
		}

		BlockPos found = findObstacleBetweenStalkerAndPlayer(world, player);
		if (found == null) {
			return false;
		}

		this.targetPos = found;
		Block block = world.getBlockState(found).getBlock();
		this.hitsRequired = isFence(block) ? HITS_REQUIRED_FENCE : HITS_REQUIRED_DOOR;
		this.hitsLanded = 0;
		return true;
	}

	@Override
	public boolean shouldContinue() {
		if (this.targetPos == null) {
			return false;
		}

		if (!(this.stalker.getEntityWorld() instanceof ServerWorld world)) {
			return false;
		}

		PlayerEntity player = this.stalker.resolveTargetPlayer();
		if (player == null || !player.isAlive()) {
			return false;
		}

		BlockState state = world.getBlockState(this.targetPos);
		return isBreakableObstacle(state.getBlock())
				&& isClosed(state)
				&& isObstacleBetweenStalkerAndPlayer(world, player, this.targetPos)
				&& this.hitsLanded < this.hitsRequired;
	}

	@Override
	public void start() {
		this.hitCooldown = 0;
	}

	@Override
	public void stop() {
		this.targetPos = null;
		this.stalker.getNavigation().stop();
	}

	@Override
	public void tick() {
		if (this.targetPos == null) {
			return;
		}

		Vec3d center = Vec3d.ofCenter(this.targetPos);
		this.stalker.getLookControl().lookAt(center.x, center.y, center.z);

		double distSq = this.stalker.getEntityPos().squaredDistanceTo(center);
		if (distSq > 4.5D) {
			this.stalker.getNavigation().startMovingTo(center.x, center.y, center.z, 0.9D);
			return;
		}

		this.stalker.getNavigation().stop();
		if (this.hitCooldown > 0) {
			this.hitCooldown--;
			return;
		}

		this.hitCooldown = HIT_INTERVAL_TICKS;
		this.hitsLanded++;
		this.stalker.swingHand(Hand.MAIN_HAND);
		StalkerSoundManager.playDoorBreak(this.stalker);

		if (this.hitsLanded >= this.hitsRequired) {
			breakObstacle();
		}
	}

	private void breakObstacle() {
		if (!(this.stalker.getEntityWorld() instanceof ServerWorld world) || this.targetPos == null) {
			return;
		}

		PlayerEntity player = this.stalker.resolveTargetPlayer();
		if (player == null || !isObstacleBetweenStalkerAndPlayer(world, player, this.targetPos)) {
			this.targetPos = null;
			return;
		}

		BlockState state = world.getBlockState(this.targetPos);
		Block block = state.getBlock();
		boolean broken = false;

		if (block instanceof DoorBlock && state.contains(Properties.DOUBLE_BLOCK_HALF)) {
			boolean isLower = state.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.LOWER;
			BlockPos otherHalf = isLower ? this.targetPos.up() : this.targetPos.down();
			broken = world.breakBlock(this.targetPos, DROP_BLOCK_ON_BREAK, this.stalker);
			if (world.getBlockState(otherHalf).getBlock() instanceof DoorBlock) {
				world.breakBlock(otherHalf, DROP_BLOCK_ON_BREAK, this.stalker);
			}
		} else {
			broken = world.breakBlock(this.targetPos, DROP_BLOCK_ON_BREAK, this.stalker);
		}

		if (broken) {
			StalkerSoundManager.queueAmbient2AfterDoorBreak(this.stalker);
		}
		this.targetPos = null;
	}

	/**
	 * Devuelve el primer bloque solido que intercepta la linea entre Stalker y
	 * jugador, pero solo si ese bloque es una puerta/trampilla/valla cerrada.
	 */
	private BlockPos findObstacleBetweenStalkerAndPlayer(ServerWorld world, PlayerEntity player) {
		Vec3d[] starts = {
				this.stalker.getEyePos(),
				this.stalker.getEntityPos().add(0.0D, 0.6D, 0.0D)
		};
		Vec3d[] ends = {
				player.getEyePos(),
				player.getEntityPos().add(0.0D, 0.6D, 0.0D)
		};

		for (int i = 0; i < starts.length; i++) {
			BlockHitResult hit = world.raycast(new RaycastContext(
					starts[i],
					ends[i],
					RaycastContext.ShapeType.COLLIDER,
					RaycastContext.FluidHandling.NONE,
					this.stalker
			));

			if (hit.getType() != net.minecraft.util.hit.HitResult.Type.MISS) {
				BlockPos pos = hit.getBlockPos();
				BlockState state = world.getBlockState(pos);
				if (isBreakableObstacle(state.getBlock()) && isClosed(state)) {
					return pos;
				}
			}
		}

		return null;
	}

	private boolean isObstacleBetweenStalkerAndPlayer(
			ServerWorld world,
			PlayerEntity player,
			BlockPos obstacle) {

		BlockPos found = findObstacleBetweenStalkerAndPlayer(world, player);
		return obstacle.equals(found);
	}

	private static boolean isBreakableObstacle(Block block) {
		return block instanceof DoorBlock || block instanceof TrapdoorBlock || isFence(block);
	}

	private static boolean isFence(Block block) {
		return block instanceof FenceBlock || block instanceof FenceGateBlock;
	}

	private static boolean isClosed(BlockState state) {
		if (state.contains(Properties.OPEN)) {
			return !state.get(Properties.OPEN);
		}
		return true;
	}
}
