package com.manguangua.thestalker.spawn;

import com.manguangua.thestalker.TheStalker;
import com.manguangua.thestalker.entity.TheStalkerEntity;
import com.manguangua.thestalker.sound.StalkerSoundManager;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

/**
 * Controla CUANDO aparece (o reaparece) el Stalker.
 *
 * No contiene logica de comportamiento (eso vive en los Goals);
 * solo decide "toca spawnear" y, si es asi, busca un punto valido
 * y crea/reubica la entidad.
 *
 * Reglas:
 * - Primer spawn: a los 2 minutos y 37 segundos (3140 ticks) del mundo,
 *   a 30-50 bloques del jugador, a ser posible fuera de su campo de vision.
 *
 * - Cuando el Stalker muere: reaparece 40 segundos (800 ticks) despues.
 *
 * - Solo se ejecuta en el Overworld para evitar duplicados entre dimensiones.
 */
public final class StalkerSpawnHandler {

	private static final double FIRST_SPAWN_MIN_DIST = 30.0;
	private static final double FIRST_SPAWN_MAX_DIST = 50.0;

	private static final double RESPAWN_MIN_DIST = 40.0;
	private static final double RESPAWN_MAX_DIST = 80.0;

	/** 40 segundos, en ticks (20 ticks = 1 segundo). */
	private static final long RESPAWN_DELAY_TICKS = 800L;

	private static final int MAX_PLACEMENT_ATTEMPTS = 500;

	private StalkerSpawnHandler() {
	}

	/**
	 * Se ejecuta al final de cada tick del mundo.
	 */
	public static void onEndWorldTick(ServerWorld world) {

		// El Stalker solo se controla desde el Overworld.
		if (world.getRegistryKey() != World.OVERWORLD) {
			return;
		}

		StalkerWorldState state = getState(world);
		long worldTime = world.getTime();

		// =========================================================
		// PRIMER SPAWN
		// =========================================================

		if (!state.isFirstSpawnDone()) {
			if (worldTime >= state.getNextSpawnCheckTime()) {
				attemptFirstSpawn(world, state);
			}
			return;
		}

		// Las reapariciones solo se activan cuando no hay un Stalker registrado.
		// El momento de reaparicion se fija en la muerte y NO se reinicia
		// cuando un punto de spawn resulta temporalmente invalido.
		if (state.getStalkerEntityUuid() == null
				&& worldTime >= state.getNextSpawnCheckTime()) {
			boolean spawned = attemptRespawnCheck(world, state);
			if (!spawned) {
				// El retraso de 800 ticks ya se cumplio. Si todavia no hay
				// un punto libre, reintentamos cada segundo, pero el contador
				// de 40 s NO vuelve a empezar.
				state.setNextSpawnCheckTime(worldTime + 20L);
			}
		}
	}

	/**
	 * Intenta realizar el primer spawn del Stalker.
	 */
	private static void attemptFirstSpawn(
			ServerWorld world,
			StalkerWorldState state) {

		PlayerEntity target = pickWorldCreator(world);

		if (target == null) {
			// Nadie conectado todavía.
			// Se volverá a intentar en el siguiente tick.
			return;
		}

		BlockPos spawnPos = findValidSpawnPos(
				world,
				target,
				FIRST_SPAWN_MIN_DIST,
				FIRST_SPAWN_MAX_DIST,
				true
		);

		if (spawnPos == null) {
			// No se encontró un lugar válido.
			return;
		}

		TheStalkerEntity stalker = spawnAt(
				world,
				spawnPos,
				target
		);

		if (stalker == null) {
			return;
		}

		state.setTargetPlayerUuid(target.getUuid());
		state.setStalkerEntityUuid(stalker.getUuid());
		state.setFirstSpawnDone(true);

		state.setNextSpawnCheckTime(world.getTime());

		StalkerSoundManager.playSpawn(stalker);

		TheStalker.LOGGER.info(
				"[TheStalker] Primer spawn realizado cerca de {}",
				target.getName().getString()
		);
	}

	/**
	 * Comprueba si es necesario crear un nuevo Stalker.
	 */
	private static boolean attemptRespawnCheck(
			ServerWorld world,
			StalkerWorldState state) {

		UUID existingUuid = state.getStalkerEntityUuid();

		if (existingUuid != null) {
			/*
			 * El Stalker actual sigue registrado.
			 *
			 * Es una entidad persistente, por lo que no se crea
			 * otro Stalker mientras este exista.
			 *
			 * Cuando muera, TheStalkerEntity llamará a:
			 *
			 *     onStalkerDied(...)
			 *
			 * y el UUID será limpiado.
			 */
			return false;
		}

		PlayerEntity target = resolveTargetOrNearest(
				world,
				state
		);

		if (target == null) {
			return false;
		}

		BlockPos spawnPos = findValidSpawnPos(
				world,
				target,
				RESPAWN_MIN_DIST,
				RESPAWN_MAX_DIST,
				false
		);

		if (spawnPos == null) {
			return false;
		}

		TheStalkerEntity stalker = spawnAt(
				world,
				spawnPos,
				target
		);

		if (stalker == null) {
			return false;
		}

		state.setStalkerEntityUuid(stalker.getUuid());
		state.setNextSpawnCheckTime(world.getTime());

		StalkerSoundManager.playSpawn(stalker);

		TheStalker.LOGGER.info(
				"[TheStalker] El Manguangua ha reaparecido."
		);

		return true;
	}


	/**
	 * Se llama desde TheStalkerEntity cuando la entidad muere.
	 *
	 * Esto permite que pueda reaparecer posteriormente.
	 */
	public static void onStalkerDied(
			ServerWorld world,
			UUID deadStalkerUuid) {

		StalkerWorldState state = getState(world);

		if (deadStalkerUuid.equals(
				state.getStalkerEntityUuid())) {

			state.setStalkerEntityUuid(null);
			state.setNextSpawnCheckTime(world.getTime() + RESPAWN_DELAY_TICKS);
			TheStalker.LOGGER.info(
					"[TheStalker] El Manguangua murio; reaparecera en 40 segundos."
			);
		}
	}

	// =========================================================
	// ESTADO PERSISTENTE
	// =========================================================

	public static StalkerWorldState getState(ServerWorld world) {

		return world
				.getPersistentStateManager()
				.getOrCreate(StalkerWorldState.TYPE);
	}

	// =========================================================
	// SELECCIÓN DEL JUGADOR
	// =========================================================

	/**
	 * Busca al jugador que probablemente creó el mundo.
	 *
	 * Si hay varios jugadores, se selecciona el que está más
	 * cerca del punto de spawn del mundo.
	 *
	 * Compatible con la API actual usando getSpawnPoint().
	 */
	private static PlayerEntity pickWorldCreator(
			ServerWorld world) {

		List<? extends PlayerEntity> players =
				world.getPlayers();

		if (players.isEmpty()) {
			return null;
		}

		if (players.size() == 1) {
			return players.get(0);
		}

		/*
		 * CORRECCIÓN:
		 *
		 * Antes se utilizaba:
		 *
		 *     world.getSpawnPos()
		 *
		 * Ese método no existe en la API utilizada por
		 * Minecraft 1.21.11.
		 *
		 * Ahora obtenemos la posición mediante el SpawnPoint.
		 */
		BlockPos worldSpawn =
				world.getSpawnPoint().getPos();

		PlayerEntity closest = null;

		double bestDist = Double.MAX_VALUE;

		for (PlayerEntity p : players) {

			double d =
					p.getBlockPos()
							.getSquaredDistance(worldSpawn);

			if (d < bestDist) {
				bestDist = d;
				closest = p;
			}
		}

		return closest;
	}

	/**
	 * Obtiene el jugador objetivo registrado.
	 * Si ya no está conectado, utiliza al jugador más cercano
	 * al spawn del mundo.
	 */
	private static PlayerEntity resolveTargetOrNearest(
			ServerWorld world,
			StalkerWorldState state) {

		UUID targetUuid =
				state.getTargetPlayerUuid();

		if (targetUuid != null) {

			PlayerEntity player =
					world.getPlayerByUuid(targetUuid);

			if (player != null && player.isAlive()) {
				return player;
			}
		}

		return pickWorldCreator(world);
	}

	// =========================================================
	// CREACIÓN DEL STALKER
	// =========================================================

	/**
	 * Crea y coloca el Stalker en la posición indicada.
	 */
	public static TheStalkerEntity spawnAt(
			ServerWorld world,
			BlockPos pos,
			PlayerEntity target) {

		TheStalkerEntity stalker =
				TheStalkerEntity.create(world);

		if (stalker == null) {
			return null;
		}

		stalker.refreshPositionAndAngles(
				pos.getX() + 0.5,
				pos.getY(),
				pos.getZ() + 0.5,
				0.0F,
				0.0F
		);

		stalker.setTargetPlayer(
				target.getUuid()
		);

		if (!world.spawnEntity(stalker)) {
			return null;
		}

		return stalker;
	}

	// =========================================================
	// BÚSQUEDA DEL PUNTO DE SPAWN
	// =========================================================

	/**
	 * Busca un BlockPos válido a distancia [minDist, maxDist]
	 * del jugador.
	 *
	 * Requisitos:
	 *
	 * - Superficie sólida.
	 * - Dos bloques de aire encima.
	 * - Sin líquido.
	 *
	 * Si preferOutOfSight es true, se intentan primero
	 * posiciones detrás del jugador.
	 */
	public static BlockPos findValidSpawnPos(
			ServerWorld world,
			PlayerEntity player,
			double minDist,
			double maxDist,
			boolean preferOutOfSight) {

		Vec3d playerLook =
				preferOutOfSight
						? player.getRotationVec(1.0F)
						: null;

		for (
				int attempt = 0;
				attempt < MAX_PLACEMENT_ATTEMPTS;
				attempt++
		) {

			double angle =
					world.getRandom().nextDouble()
							* Math.PI * 2.0;

			double dist =
					minDist
							+ world.getRandom().nextDouble()
							* (maxDist - minDist);

			double dx =
					Math.cos(angle) * dist;

			double dz =
					Math.sin(angle) * dist;

			// =================================================
			// PREFERIR LA ESPALDA DEL JUGADOR
			// =================================================

			if (
					preferOutOfSight
							&& playerLook != null
			) {

				double dot =
						(playerLook.x * dx)
								+ (playerLook.z * dz);

				/*
				 * Si el punto está delante del jugador,
				 * se descarta durante los primeros intentos.
				 */
				if (
						dot > 0
								&& attempt
								< MAX_PLACEMENT_ATTEMPTS / 2
				) {
					continue;
				}
			}

			int x =
					player.getBlockPos().getX()
							+ (int) Math.round(dx);

			int z =
					player.getBlockPos().getZ()
							+ (int) Math.round(dz);

			int y =
					world.getTopY(
							Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
							x,
							z
					);

			BlockPos candidate =
					new BlockPos(x, y, z);

			if (isValidGround(world, candidate)) {
				return candidate;
			}
		}

		// Segundo pase determinista: garantiza que una mala secuencia
		// aleatoria no impida la reaparicion. Recorremos un anillo
		// amplio alrededor del jugador y usamos la altura del terreno.
		int centerX = player.getBlockPos().getX();
		int centerZ = player.getBlockPos().getZ();
		int radius = (int) Math.ceil(maxDist);

		for (int dx = -radius; dx <= radius; dx++) {
			for (int dz = -radius; dz <= radius; dz++) {
				double dist = Math.sqrt((double) dx * dx + (double) dz * dz);
				if (dist < minDist || dist > maxDist) {
					continue;
				}

				int x = centerX + dx;
				int z = centerZ + dz;
				int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
				BlockPos candidate = new BlockPos(x, y, z);

				if (isValidGround(world, candidate)) {
					return candidate;
				}
			}
		}

		return null;
	}

	/**
	 * Comprueba que el lugar sea adecuado para colocar
	 * al Stalker.
	 */
	private static boolean isValidGround(
			ServerWorld world,
			BlockPos pos) {

		BlockPos below = pos.down();

		BlockState belowState =
				world.getBlockState(below);

		// El bloque debajo no puede ser aire.
		if (belowState.isAir()) {
			return false;
		}

		// El bloque debajo no puede contener líquido.
		if (!belowState.getFluidState().isEmpty()) {
			return false;
		}

		// Debe ser un bloque sólido.
		if (!belowState.isSolidBlock(world, below)) {
			return false;
		}

		/*
		 * La entidad necesita dos bloques de aire:
		 *
		 *   [aire]     <- pos.up()
		 *   [Stalker]  <- pos
		 *   [suelo]    <- pos.down()
		 */
		return world.getBlockState(pos).isAir()
				&& world.getBlockState(pos.up()).isAir();
	}
}