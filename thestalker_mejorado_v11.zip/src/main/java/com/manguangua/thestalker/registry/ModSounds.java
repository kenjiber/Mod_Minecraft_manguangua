package com.manguangua.thestalker.registry;

import com.manguangua.thestalker.TheStalker;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class ModSounds {

	public static final SoundEvent STALKER_AMBIENT_PRIMARY = register("stalker.ambient_primary");
	public static final SoundEvent STALKER_DESPAIR_AMBIENT = register("stalker.despair_ambient");
	public static final SoundEvent STALKER_DESPAIR_1 = register("stalker.despair_1");
	public static final SoundEvent STALKER_AMBIENT_AFTER_DOOR = register("stalker.ambient_after_door");
	public static final SoundEvent STALKER_AMBIENT_3 = register("stalker.ambient_3");
	public static final SoundEvent STALKER_SPAWN = register("stalker.spawn");
	public static final SoundEvent STALKER_STARE = register("stalker.stare");
	public static final SoundEvent STALKER_DOOR_BREAK = register("stalker.door_break");

	private ModSounds() {
	}

	private static SoundEvent register(String path) {
		Identifier id = Identifier.of(TheStalker.MOD_ID, path);
		return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
	}

	public static void register() {
		TheStalker.LOGGER.info("[TheStalker] Sonidos registrados.");
	}
}
